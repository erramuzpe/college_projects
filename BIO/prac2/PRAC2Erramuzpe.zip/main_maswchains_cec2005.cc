/**
 * Copyright 2008, Daniel Molina Cabrera <danimolina@gmail.com>
 * 
 * This file is part of software Realea
 * 
 * Realea is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Realea is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <realea/problem/problemcec2005.h>
#include <realea/common/ilocalsearch.h>
#include <realea/common/cross.h>
#include <realea/common/ea.h>
#include <ea/ssga/ssga.h>
#include <localsearch/solis.h>
#include <realea/common/srandom.h>
#include "malschains.h"
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cassert>

using namespace realea;
using namespace std;
using std::auto_ptr;

void usage(char *prog) {
	printf("This algorithm applies the MA-LS-Chains algorithm to the Workshop Real Continuous Optimization Problems from CEC'2005.\n");
	printf("usage: %s fun dim [maxrun=25]\n", prog);
	printf("Where\tfun is the number of function (1 to 25)\n\tdim is the dimensionality (10|30|50)");
	printf("\n\tmaxrun is the maximum times (default=25)\n");
}

Hybrid *processData(int argc, char **argv, DomainReal *domain, Random &random) {
     string alg,arg_ls, arg_effort, arg_maxeval;

     if (argc > 1) {
	alg = argv[1];
     }
     if (argc > 2) {
	arg_ls = 30;
     }


     SSGA *ssga = new SSGA(&random);
     ssga->setCross(new CrossBLX(0.5));
     ssga->setMutation(new MutationBGA());
     ssga->setSelect(new SelectNAM(3));
     ssga->setReplacement(new ReplaceWorst());

     IEA *ea = ssga;
     SolisWets *sw = new SolisWets();
     sw->setDelta(0.2);
     ILocalSearch *ls = sw;

     MALSChains *ma = new MALSChains(ea, ls);
     ma->setDebug();
     ma->setRestart(new RestartBest());
     Hybrid *hybrid = ma;
     hybrid->setEffortRatio(0.5);
     hybrid->setIntensity(500);
     return hybrid;
}

int main(int argc, char **argv) {
    unsigned int dim = 100;

    try {
	int fun,ran;



	fun = atoi(argv[1]);
	dim = 30;

	if (dim > 1000) {
	    dim = 1000;
	}

	printf("Fun: %d[%d]\n", fun, dim);

	

	// Defino el problema indicando el umbral 
	for (int num = 15; num <= 20; num++) {


		// Chapuza, pero funciona
		if (num == 1) {ran = 12345;}
		if (num == 2) {ran = 23456;}
		if (num == 3) {ran = 34567;}
		if (num == 4) {ran = 45678;}
		if (num == 5) {ran = 56789;}
		if (num == 6) {ran = 67890;}
		if (num == 7) {ran = 78901;}
		if (num == 8) {ran = 89012;}
		if (num == 9) {ran = 90123;}
		if (num == 10) {ran = 01234;}
		if (num == 11) {ran = 123456;}
		if (num == 12) {ran = 234567;}
		if (num == 13) {ran = 345678;}
		if (num == 14) {ran = 456789;}
		if (num == 15) {ran = 567890;}
		if (num == 16) {ran = 678901;}
		if (num == 17) {ran = 789012;}
		if (num == 18) {ran = 890123;}
		if (num == 19) {ran = 901234;}
		if (num == 20) {ran = 012345;}
	    	Random random(new SRandom(ran));


ProblemCEC2005 problem(&random, dim);
	ProblemPtr prob = problem.get(fun);

	tChromosomeReal sol(dim);
	tFitness fitness=0;

	Hybrid *hybrid = processData(argc-2, argv+2, prob->getDomain(), random);	
	string algname(argv[1]);
	EA alg(hybrid, prob);
	tFitness sum=0;
	    alg.apply(sol, &fitness);
	    printf("%Le\n", fitness);
	    sum += fitness;
	}
	//printf("mean:%Le\n", sum/maxRun);

    } catch (ConfigException *e) {
	    cerr <<"ConfigException : " <<e->what() <<endl;
	    delete e;
    } catch (RunningException *e) {
	    cerr <<"RunningException : " <<e->what() <<endl;
	    delete e;
    } catch (runtime_error *e) {
	    cerr <<"runtime_error: " <<e->what() <<endl;
	    delete e;
    } catch (exception &e) {
	    cerr <<"Exception : " <<e.what() <<endl;
    }
    catch (string &str) {
	    cerr <<"StrException : " <<str <<endl;
    }
    catch (string *str) {
	    cerr <<"StrException : " <<*str <<endl;
	    delete str;
    }

    return 0;
}
