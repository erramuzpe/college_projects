/**
 * Copyright 2008, Daniel Molina Cabrera <danimolina@gmail.com>
 * 
 * This file is part of software Realea
 * 
 * Realea is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Realea is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <realea/common/srandom.h>
#include <realea/common/ea.h>
#include <realea/problem/problemcec2005.h>
#include "chc.h"
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <cassert>

using namespace realea;

void usage(char *prog) {
	printf("usage: %s fun dim [maxrun=25]\n", prog);
}


int main(int argc, char **argv) {
	unsigned int dim;
	int fun, ran;

	try {


	fun = atoi(argv[1]);
	dim = 30;


	if (dim > 1000) {
	    dim = 1000;
	}

	printf("Fun: %d[%d] \n", fun, dim);


	for (int num = 1; num <= 20; num++) {

		// Chapuza, pero funciona
		if (num == 1) {ran = 12345;}
		if (num == 2) {ran = 23456;}
		if (num == 3) {ran = 34567;}
		if (num == 4) {ran = 45678;}
		if (num == 5) {ran = 56789;}
		if (num == 6) {ran = 67890;}
		if (num == 7) {ran = 78901;}
		if (num == 8) {ran = 89012;}
		if (num == 9) {ran = 90123;}
		if (num == 10) {ran = 01234;}
		if (num == 11) {ran = 123456;}
		if (num == 12) {ran = 234567;}
		if (num == 13) {ran = 345678;}
		if (num == 14) {ran = 456789;}
		if (num == 15) {ran = 567890;}
		if (num == 16) {ran = 678901;}
		if (num == 17) {ran = 789012;}
		if (num == 18) {ran = 890123;}
		if (num == 19) {ran = 901234;}
		if (num == 20) {ran = 012345;}
	    	Random random(new SRandom(ran));

	ProblemCEC2005 problem(&random, dim);
	ProblemPtr prob = problem.get(fun);
	CHC *chc = new CHC(&random);
	EA ea(chc, prob);
	chc->setCross(new CrossBLX(0.5));
	tChromosomeReal sol(dim);
	tFitness fitness;
	    ea.apply(sol, &fitness);
	    fitness = prob->eval(sol);
	    fprintf(stdout, "%Le\n", fitness);
	}
    } catch (ConfigException *e) {
	cerr <<"Exception : " <<e->what() <<endl;
	delete e;
    } catch (runtime_error *e) {
	cerr <<"Exception : " <<e->what() <<endl;
	delete e;
    } catch (runtime_error &e) {
	cerr <<"Exception : " <<e.what() <<endl;
    } catch (exception &e) {
	cerr <<"Exception : " <<e.what() <<endl;
    }
    catch (string &str) {
	cerr <<"StrException : " <<str <<endl;
    }

    return 0;
}

//#include "chc.cc"
//int main(int argc, char **argv) {
//	string crossover_str, popsize_str, functions_str, function_str;
//
//        crossover_str = "blx";
//        popsize_str = "50";
//        functions_str = "cec2005";
//        function_str = "1";
//	
//	getConfigUser().realParam(string(crossover_str), string(popsize_str), 
//		  string(functions_str), string(function_str));
//
//	double *sol;
//        int dim;
//        double fit;
//
//	chc(&sol, &dim, &fit);
//	printf("Fitness alcanzado en %s::%s = %lf\n", functions_str.c_str(), function_str.c_str(), fit);
//	return 0;
//}
