/*
 Balanced PSO, based on Standard PSO 2007
 Version for the Handbook of Swarm Intelligence

 The research version, with more options, can be found on
 http://clerc.maurice.free.fr/pso/
 Contact for remarks, suggestions etc.:
 Maurice.Clerc@WriteMe.com
 PS. Don't tell me the code is not optimised. I know it ;-)
 But if you find a bug, don't hesitate!
 ----------------------------------- Parameters S := swarm size K := maximum number of particles _informed_ by a given one w := first cognitive/confidence coefficient c := second cognitive/confidence coefficient ----------------------------------- Equations For each particle and each dimension Equation 1:	v(t+1) = w*v(t) + R(c1)*(p(t)-x(t)) + R(c2)*(g(t)-x(t)) Equation 2:	x(t+1) = x(t) + v(t+1) where v(t) := velocity at time t x(t) := position at time t p(t) := best previous position of the particle g(t) := best position amongst the best previous positions 					of the informants of the particle R(c) := a number coming from a random distribution, which depends on c In SPSO 2007, the distribution is uniform on [0,c] Note 1: When the particle has no informant better than itself, it implies p(t) = g(t) Equation 1 is then modified: v(t+1) = w*v(t) + R(c)*(p(t)-x(t))   
 ----------------------------------- Options
	There are a lot of options, see at the beginning of "main" for details.

 Each option has a "code", which points out the difference with SPSO 2007.
 This code is displayed at the end of the run. For example: 
 PSO P2 V3
 means
 "SPSO 2007, but with option 2 (improved Hammersley) for the initialisation of the positions,
 and option 3 (set to zero) for the initialisation of the velocities

 ----------------------------------- Miscellaneous
- the search space can be any real hyperparallelepid, but the values can be discretised
	(granularity)
- some combinations of options are "stupid". Sometimes I check the possible
	inconsistencies, sometimes not. Be careful.
- there are sub-parameters hard coded for some variants. For example the 
  standard deviation for a Gaussian distribution. 

 */


#include "stdio.h"
#include "math.h"
#include <stdlib.h>
#include <time.h>
/*
	 By using KISS, a pseudo-random number generator directly coded here,
	 results are more reproducible
	 */#define ulong unsigned long #define RAND_MAX_KISS ((unsigned long) 4294967295)

// Define some max-min values. Can of course be modified

#define	DMax 60			// Max number of dimensions of the search space
#define LMax 500 		// Max size of a local position list. Should be >= DMax+1
#define RMax 101		// Max number of runs
#define	SMax 100		// Max swarm size
#define stratMax 3 		// Maximum number of different strategies
#define zero  1.0e-30	// To avoid numerical instabilities with some compilers#define infinity 1.0e30
#define ClassMax 50 	// Max number of points for the curve "success rate vs FEmax"

#define ERROR(a) {printf("ERROR: %s\n", a);exit(-1);}
//-------------------- Structuresstruct quantum 
{
	double q[DMax];
	int size; };
struct SS 
{ 	int D;
	double max[DMax];  	// Initialisation, and feasible space
	double min[DMax]; 	struct quantum q;		// Quantisation step size. 0 => continuous problem
	double maxS[DMax];	// Search space
	double minS[DMax];
	int valueNb; 		 	// if >0, the search space is a list of "valueNb"values.
};
struct param 
{
	int aroundNb; 		// Nb of points "around" a given one, for "smoothed" evaluation
	double c1;			// Confidence coefficient	double c2;			// Idem. For the moment, c1=c2
	int clamping;			// Position clamping or not	int K;				// Max number of particles informed by a given one
	int choose_LEA;		// Define the kind of Local Exploitation Area
	int draw_LEA;			// How a point is sampled (drawn) in the LEA	double force_LEA;		// Whether a particle is forced to a LEA or not	double size_LEA;		// Relative size of the LEA	int explOption;		// How size_LEA is modified during the run	int init;				// How the position is initialised
	int initLink; 		// What kind of re-initialisation for the links
	int initLinkNbMax;
	int initVel;			// How the velocity is initialised 
	int opposite;			// Experimental. One may take the "opposite" of a particle	double p;				// Probability threshold for random topology										// (is actually computed as p(S,K) )
	int R; 				// Kind of random distribution R
	int rand; 			// Kind of randomness (KISS or computer dependent)	int randOrder;		// Random choice of particles or not
	int S;				// Swarm size
	double select;	// Proportion of bad particles that are reinitialised
	double sigma; 		// Standard deviation if Gaussian distribution (R=1)t
	int stop;				// Flag for stop criterion
	int strat; 			// Strategy to use
	double w[stratMax];	// "weight" coefficient for the velocity
	double w0Rate; 		// Rate of particles using local strategy 0 (when param.strat=1)	};
struct position 
{ 	double f;				// Fitness value  	int improved;			// Has been improved or not   	int size;				// Number of dimensions  D	double x[DMax];		// Coordinates	int forced;			// Has been forced or not
	double d; 			// Distance to a given point};
struct velocity 
{  	int size;				// Number of dimensions D  	double v[DMax]; 		// Components};struct problem 
{ 	double epsilon; 		// Admissible error	int evalMax; 			// Maximum number of fitness evaluations	int function; 		// Function code	double objective; 	// Objective value						struct position solution; // Solution position (if known, just for tests)		struct SS SS;			// Search space
};
struct swarm 
{ 	int best; 				// Rank of the best particle	struct position P[SMax];	// Previous best positions found by each particle	struct position Pp[SMax]; // Previous previous best (for information)	int lBest[SMax]; 			// Flag: lBest[s]=1 means Pp[s] was a local best	int S; 					// Swarm size 	struct velocity V[SMax];	// Velocities
	struct position X[SMax];	// Positions
	struct position XPrev[SMax]; // Previous positions
	double w[SMax];			// "weight", for each particle
	double c[SMax];			// Confidence coefficient, for each particle
	int R[SMax];				// Distribution R, for each particle
	int worst;				// Rank of the worst particle};
struct result 
{  	double nEval; 			// Number of evaluations  	struct swarm SW;			// Final swarm	double error;				// Numerical result of the run
	double convRate; 			// For information: how fast has been the convergence};

struct sF{int s; double f;}; // To sort the position according to the fitnessstruct lBest {int rank; double x[DMax];}; // To sort the local bests// ---- Specific to LEA (Local exploitation areas)// rank[] = flags. rank[i]=1 means "particle i is a local best"// ex[] = search space "around" each local beststruct exploit {int rank[SMax]; struct SS exI[SMax];};struct posList {int size; struct position p[LMax];}; 

// -------------------- Sub-programsulong	rand_kiss(); // For the pseudo-random number generator KISSvoid	seed_rand_kiss(ulong seed); // "
double alea (double a, double b);int alea_integer (int a, int b);double alea_normal (double mean, double stdev);struct position hammersley(struct SS SS, int S, int deb, int s);double perf (struct position x, struct problem pb, int option, int aroundNb, int S);	// Fitness evaluationstruct position quantis (struct position x, struct SS SS);struct problem problemDef(int functionCode);
struct quantum quantAdapt(struct swarm SW, struct problem pb);struct result PSO ( struct param param, struct problem problem, int level);int sign (double x); // Warning, this is not the classical sign function// Subroutines for local searchstruct exploit exploitArea(struct swarm SW, struct SS SS,double rho);double explNb(struct swarm SW, struct exploit ex );
static int compareF (void const *a, void const *b); static int compareLBest (void const *a, void const *b); // For qsort

// Global variables
long double E;			// exp(1). Useful for some test functions
long double pi;			// Useful for some test functionsint dLBest; 			// For information
int randOption; 		// Kind of randomness to use
double distPow; 		// For decreasing random distribution coefficient  (R>=2)

int successFlag[RMax][ClassMax]={0}; // To compute the success rate "on the run"
int FEmax[ClassMax];
int FEmaxSize;
int FEclass;
int run;
int iter;
double best[RMax][ClassMax]; // To compute the mean best "in passing"


// File(s);
FILE * f_run;FILE * f_synth;FILE * f_expl;
FILE * f_init;
FILE * f_init_save;
FILE * fCurve;

// =================================================
int main () 
{ 
	struct position bestBest;
	double convRateMean;
	int d;					// Current dimension
	double error;				// Current error
	double errorMean;			// Average error
	double errorMin=infinity;	// Best result over all runs
	double errorMeanBest[RMax]; 	double evalMean;			// Mean number of evaluations	int functionCode;
	int j;
	int initLink;
	int n;	int nFailure;				// Number of unsuccessful runs	double logProgressMean=0;
	struct param param={0};	struct problem pb={0}; 	int  runMax; 	struct result result; 
	int SPSO07; 				// To simulate SPSO07	double successRate;	double variance;
	int wSize;
	double zz,zz1;

	f_run = fopen ("f_run.txt", "w");  	f_synth = fopen ("f_synth.txt", "w"); 	f_expl = fopen ("f_expl.txt", "w"); // Just for info (exploitation rate)
	f_init_save=fopen("f_init_save.txt","w");
	fCurve=fopen("fCurve.txt","w");
	E = exp ((long double) 1); 	pi = acos ((long double) -1);

	//---------- For the curve "fitness vs FE"
	FEmaxSize=20;// If >0, save info in order to plot the curve (success_rate vs FEmax)
	for(n=0;n<FEmaxSize;n++)

		//FEmax[n]=5000+5000*n; // Rosenbrock F1
		// FEmax[n]=500+500*n; // Tripod
		FEmax[n]=1000+1000*n; // Compression spring, Gear train, Cellular phone


	param.stop = 0;	// Stop criterion
	// 0 => error < pb.epsilon  
	// 1 => eval = pb.evalMax	 
	// WARNING. When the variance is quite large,
	// using 0 or 1 may give different results, unless the number of runs is very
	// high (typically at least 500)

	//--------- Simulation of Standard PSO 2007
	SPSO07=1; // 1 => "simulate" Standard PSO 2007. 
	/*
	 All other parameters/options are then ignored
	 Note that the result can not be exactly the same, for the pseudo-random numbers 
	 are not used the same way. For example, in SPSO07 you have an initialisation loop
	 for each particle
	 	initialise the position
	 	initialise the velocity

	 Here, we have two loops:
	 for each particle, initialise the position
	 for each particle, initial=ise the velocity

	 Therefore, as soon as randomness is used,
	 initial positions and velocities are different
	 */

	// ----------------------------------------------- PROBLEM
	functionCode = 4;	
	/* (see problemDef( ), and cec2005pb.c for precise definitions)
	 0 Parabola (Sphere)
	 1 Griewank
	 2 Rosenbrock (Banana)
	 3 Rastrigin
	 4 Tripod (dimension 2)	 5 Ackley
	 7 Pressure vessel
	 8 Compression spring
	 9 Gear train
	 10 Cellular phone
	 12 Schwefel	 CEC 2005 benchmark	 100 F1 (shifted Parabola/Sphere) 30D	 102 F6 (shifted Rosenbrock) 10D	 103 F9 (shifted Rastrigin) 10D 
	 104 F2 Schwefel
	 105 F7 Griewank (NOT rotated)
	 106 F8 Ackley (NOT rotated) 
	 */ 
	runMax = 100; // Numbers of runs
	if (runMax > RMax) runMax = RMax;

	// -----------------------------------------------------
	// PARAMETERS and OPTIONS
	// * = "suggested value"	

	if(SPSO07==1) goto runs;

	param.clamping =1; // code C (for "clamping")
	// 0 => no clamping AND no evaluation. WARNING: the program
	// 				may NEVER stop 
	//(SPSO 07) *1 => classical. Set to bounds, and velocity to zero (Standard PSO 2007)	//------	param.init=0; // P.  Initialisation of the positions
	// -1 => read from file f_init (be sure it is consistent with the other data)	//(SPSO 07) 0 => on each dimensionrandom position (uniform U(xmin,xmax))	// 1 => random position (centre biased)	//* 2 => (improved) Hammersley	// 3 => random (uniform) or Hammersley
	// 5 =>  random position (centre biased), 2

	param.initLink=0; // (SPSO 07) 0 => random links after unsuccessful iteration(s)
	// 1 => random links after successful iteration(s)
	// 2 => 0 or 1, at random before each run
	param.initLinkNbMax=1;  // IL. 0 => Swarm_size/2
	//  -1 => 1/(2*p)
	// n => check if restructure, every n iterations
	// (SPSO 07, n =1)
	param.initVel=5; // V. Initialisation of the velocity for particle whose position is X
	// 0 => on each dimension U(xmin,xmax) -U(xmin,xmax)
	// * 1 => on each dimension U(xmin,xmax) - X(d)
	// 2 =>  Y - X, where Y is the initial position of another particle, chosen at random
	// 3 => set to zero
	// 4 => either 1 or 2
	// *(SPSO 07) 5 => on each dimension 0.5*( U(xmin,xmax) -X(d)) 

	param.opposite=0; //Experimental
	// 0 => nothing special (do not modify the worst particle)
	// 1 => take the "opposite" of the worst particle
	// Works well for Tripod, Parabola/Sphere, Rastrigin
	// Works more or less for Rosenbrock (2), Rastrigin (103)
	// Does _not_ work for Rosenbrock (102), Schwefel (104)


	param.choose_LEA=0; // H
	// 0 => no LEA
	// 1 => LEA of the particle 
	// 2 => best LEA 

	param.draw_LEA= 0;  // D
	// 0 => middle
	// 1 => uniform distribution
	// 2 => Gaussian distribution
	// 3 => 0 + 1
	//	param.force_LEA; // Define the rate exploit/exploration you want	// Useful only if choose_LEA > 0
	//	param.size_LEA;// Define the initial (relative) size of the exploitation area	// Useful only if choose_LEA > 0
	//	param.explOption	// 		0 => constant relative size of the exploitation area	// 		1 => variable	// 		2 => variable	// *	3 => alternative {size_LEA,1/S}	//		4 => random uniform [0,param.size_LEA]	//		5 => random Gauss (1/S, size_LEA)	// Suggested values	param.aroundNb=pb.SS.D+1; // Warning: will be different for localSearch=6 (kriging)	switch (param.choose_LEA)	{
		default: // 0. Nothing special			break;		case 1:	// LEA of the particle (i.e. around its own previous best)			param.force_LEA=0.5; 		param.size_LEA=1./3;		break;
		case 2: // LEA of the local best  (i.e. around the best previous best
			// in the neighbourhood of the particle
			param.force_LEA=0.5;
		param.size_LEA=0.5; 
		param.explOption=3;
		break;	}	//---------- Kind of distribution to use in the velocity update equation	param.R=2; // R. WARNING. Not all of these options have been carefully testes	// (SPSO 07) 0 => uniform distribution in [0,1] 	// 1 => Gaussian distribution	
	//* 2 => decreasing function of the 1D distance (see also global variable distPow)
	//* 3 => either 0 or 2
	// just to keep in mind: 4 => "smoothed" evaluation type 1 (see option 5)
	//              (mean value)
	//  5 => either 0 or 4 
	// just to keep in mind: 6 => "smoothed" evaluation type 2 (see option 7)
	//													(variable quantisation)
	//  7 => either 0 or 6 
	distPow=2; // For R=2 and R=3
	// See also param.aroundNb below, after the call of problemDef
	param.sigma=0.1; // Standard deviation for Gaussian distribution	// Useful only if R>0

	//----------
	param.rand=0; // r
	//* 0 => KISS pseudo-random number generator
	// 1 => the one of your compiler	param.randOrder=1; // O
	// 0 => at each iteration, particles are modified	//     always according to the same order 0..S-1 	//(SPSO 07)*1 => at each iteration, particles numbers are	//		randomly permutated 

	param.select=0; //  The select*S worst particles are reinitialised
										// Suggested value: 0.1
										// SPSO 2007 => 0

	//---------- General strategy to use  
	param.strat=0; // S
	// (SPSO 07) 0 => classical (just one constant w)
	// 1 => constant w0 or random w in [w0,w1], according to w0Rate  (see  below)
	// 2 => idem, but non uniform w
	// 3 => random different w for each particle
	// 4 => forced "scout" particle(s)
	// 5 => variable c

	switch(param.strat)
	{
		default: case 3: wSize=1; break;
		case 1: case 2: case 4: wSize=2; break;
	}

	runs: // =========================================================== 
		pb=problemDef(functionCode);

	printf("\n Dimension %i",pb.SS.D);

	if(SPSO07==1) // Simulate SPSO07
	{
#include "parameters.c"
		goto begin;
	}
	// You may "manipulate" S, p, w and c	// but here are the suggested values
	param.S = (int) (10 + 2 * sqrt(pb.SS.D));	// Swarm size  	if (param.S > SMax) param.S = SMax;	param.K=3; 												param.p=1-pow(1-(double)1/(param.S),param.K);
	param.w[0] = 1 / (2 * log ((double) 2)); // 0.721	param.c2 = 0.5 + log ((double) 2); // 1.193	param.c1=param.c2; 
	param.w[1]=1;
	wSize=2;

	param.w0Rate=1-1./param.S; //   In order to have about one "scout particle" 

	begin:
		randOption=param.rand;			// Some information		printf ("\n Function %i ", functionCode);
		printf("\n Swarm size %i", param.S);
		printf("\n Mean size of the neighbourhood %f", param.p*param.S);
		printf("\n (clamping, R, randOrder, exploitation, stop_criterion) = (%i,%i, %i, %i, %i)",		       param.clamping, param.R, param.randOrder,param.explOption,  param.stop);
		printf("\n randomness %i",param.rand);		printf("\n init %i",param.init);
		printf("\n initVel %i",param.initVel);
		printf("\n Strategy= %i",param.strat);
		printf("\n w ");
		for(d=0;d<wSize;d++)
			printf(" %f",param.w[d]);

		switch(param.strat)
	{
		default: break;
		case 1: case 2:
			printf("\n w0Rate %f",param.w0Rate);
			break;	
	}
		printf("\n c1 = %f, c2 = %f",param.c1,param.c2);		if(param.R==1) printf("\nStandard deviation %f",param.sigma);

		printf("\nselect = %f",param.select);		switch(param.choose_LEA)	{		default: break;
		case 1: // LEA of some particles
			printf("\n Exploitation rate  %f",param.force_LEA); 
		printf("\n Exploitation area relative side length: %f",param.size_LEA);
		break;
	}// End of choose_LEA
		switch(param.explOption)	{		default:
			break;
		case 3:			printf("\n Exploitation area relative side length: either %f or %f",1./param.S,param.size_LEA);					break;		case 4:			printf("\n Exploitation area relative side length: uniform in [0,%f]",param.size_LEA);			break;		case 5:			printf("\n Exploitation area relative side length: Gaussian (%f,%f)",1./param.S,param.size_LEA);			break;	}
		//---------------
		convRateMean=0;		errorMean = 0;	    		evalMean = 0;	    		nFailure = 0;	
		initLink=param.initLink;		//------------------------------------- RUNS			for (run = 0; run < runMax; run++)  
	{			//printf("\n run %i/%i",run+1,runMax); 
		FEclass=0;
		if(initLink==2) param.initLink=alea_integer(0,1);
		//srand (clock () / 100);	// May improve pseudo-randomness when not using KISS			result = PSO (param, pb, 0);		error = result.error;

		convRateMean=convRateMean+result.convRate;		if (error > pb.epsilon) // Failure		{
			nFailure = nFailure + 1;		}
		// Result display
		printf("\nmean %1.2e", errorMean/(run+1)); // Temporary error mean
		printf(", %0.0f %% ", (double)100*(run+1-nFailure)/(run+1)); // Temporary success rate
		printf (" %i/%i. Eval %f. Error %f ", run+1,runMax, result.nEval, error);
		printf("  x(0)= %f",(double)result.SW.P[result.SW.best].x[0]);

		// Save result
		fprintf( f_run, "\n%i %f %0.10f ", run, result.nEval,  error );
		for ( d = 0; d < pb.SS.D; d++ ) fprintf( f_run, " %0.10f",  (double)result.SW.P[result.SW.best].x[d] );


		// Compute/store some statistical information
		if (run == 0)
		{
			errorMin = error;
			bestBest=result.SW.P[result.SW.best];
		}
		else if (error < errorMin)
		{
			errorMin = error;
			bestBest=result.SW.P[result.SW.best];
		}		evalMean = evalMean + result.nEval;			errorMean = errorMean + error;			errorMeanBest[run] = error;		logProgressMean  = logProgressMean - log(error);			}		// End loop on "run"		// Display statistical information		// Means
		convRateMean=convRateMean/ (double) runMax; 
		evalMean = evalMean / (double) runMax;   		errorMean = errorMean / (double) runMax;		logProgressMean = logProgressMean/(double) runMax;

		printf ("\n Conv. rate (mean)= %f", convRateMean);				printf ("\n Eval. (mean)= %f", evalMean);			printf ("\n Error (mean) = %.12f, %.20e", errorMean,errorMean);
		// Variance
		variance = 0;
		for (run = 0; run < runMax; run++)
			variance = variance + pow (errorMeanBest[run] - errorMean, 2);
		variance = sqrt (variance / runMax);	    		printf ("\n Std. dev. %.20f", variance); 		printf("\n Log_progress (mean) = %f", logProgressMean);	
		// Success rate and minimum value		printf("\n Failure(s) %i",nFailure);
		successRate = 1 - nFailure / (double) runMax;					printf ("\n Success rate = %.2f%%", 100*successRate);
		//if (run > 1)
		printf ("\n Best min value = %f\n", errorMin);
		for ( d = 0; d < pb.SS.D; d++ ) printf( " %f", (double) bestBest.x[d] );

		// Save
		fprintf(f_synth,"    %f %f %f %.0f%% %f",errorMean,variance,errorMin,		        successRate,evalMean); 

		fprintf( f_synth, "\n %f %f %f %.0f%% %f ",
		        errorMean, variance, errorMin, successRate, evalMean );
		fprintf (f_synth, "\n");				fprintf (f_synth, "%f %f %.0f%% %f   ",
		         errorMean, variance, successRate, evalMean);		   

		// Save the best result
		fprintf( f_synth, "\n%f ", errorMin );
		for ( d = 0; d < pb.SS.D; d++ ) fprintf( f_synth, " %f", (double) bestBest.x[d] );

		// Save the curve "success rate" vs FEmax
		// Save the curve "mean best" vs FEmax

		for(j=0;j<FEmaxSize-1;j++)
	{
		zz=0;
		zz1=0;
		for(run=0;run<runMax;run++)
		{
			zz=zz+successFlag[run][j];
			zz1=zz1+best[run][j];
		}

		zz=zz/runMax; // success ratio
		zz1=zz1/runMax; // mean best

		fprintf(fCurve,"%i %e %f\n",FEmax[j],zz1,zz);
	}
		fprintf(fCurve, "%i %e %f", FEmax[FEmaxSize-1],errorMean, successRate);

		// Repeat some information about options, by using the codification
		// (by comparing to SPSO 07)
		printf("\n Function %i", functionCode);
		printf("\nResult obtained with PSO");
		if (param.clamping!=1) printf(" C%i",param.clamping);
		if(param.init !=0) printf(" P%i", param.init);
		if(param.initVel!=5) printf(" V%i", param.initVel);
		if(param.choose_LEA!=0) 
			printf(" H%i D%i",param.choose_LEA,param.draw_LEA);

		if(param.R!=0) printf(" R%i",param.R);
		if(param.rand!=1) printf(" r%i",param.rand);
		if(param.randOrder!=1) printf(" O%i",param.randOrder);
		if(param.strat!=0) printf(" S%i",param.strat);
		if(param.initLinkNbMax!=1) printf(" IL%i",param.initLinkNbMax);

		printf("\n and param.initLink = %i",param.initLink);

		return 0; // End of main program}
// ======================================================== PSO
struct result PSO (struct param param, struct problem pb, int level) 
{  	struct velocity aleaV; 	double c1,c2; 	int d; 	int deb;	double error=0; 
	double errorI; 
	double errorInit; 	double errorPrev;	struct exploit ex;	double explBestSize;	int explForced;	double explRate0, explRate;	int g[SMax]; // Best informants	int sBest; // Rank in g of the best of the bests	struct velocity GX; 	int index[SMax], indexTemp[SMax];     	int initLinks;	// Flag to (re)init or not the information links
	int initLinkNb;
	int initLinkNbMax;	int iterBegin;	int length;	int LINKS[SMax][SMax];	// Information links	struct position local={0};
	int n,m; 	int noEval; 		int noStop;	int outside;	double p;
	struct quantum qAdapt;
	struct quantum qTemp;	struct velocity PX;		struct result R={0};	int rank;	double rho;	int s0=0;
	int s,s1; 
	struct sF sF[SMax];
	int scanNb;	int t;
	double vDamp=1;
	float z;	double zz,zzz=0;	aleaV.size=pb.SS.D;

	// -----------------------------------------------------
	// INITIALISATION	p=param.p; 				// Probability threshold for random topology
	R.SW.S = param.S; // Size of the current swarm	local.size=pb.SS.D;

	// Size
	for (s = 0; s < R.SW.S; s++)   
	{		R.SW.X[s].size = pb.SS.D;		R.SW.V[s].size = pb.SS.D;	}
	// Position	switch(param.init)	{		case -1: // Read from file 
			f_init=fopen("f_initS20D30.txt","r"); // Give here the name of you file
		scanNb=	fscanf(f_init,"%i",&s0);
		if(s0!=R.SW.S)
		{
			printf("\nThe number of points (%i) in the file",s0);
			printf("\nis not consistent with the swarm size S (%i)",R.SW.S);
			ERROR(" ");
		}
		for (s = 0; s < R.SW.S; s++)   
		{	
			for (d = 0; d < pb.SS.D; d++)  
			{ 
				scanNb=fscanf(f_init,"%f",&z);
				R.SW.X[s].x[d]=z;		
			}
		}	
		break;

		default: // 0. Uniform
			for (s = 0; s < R.SW.S; s++)   
		{				for (d = 0; d < pb.SS.D; d++)  
			{  
				R.SW.X[s].x[d] = alea (pb.SS.min[d], pb.SS.max[d]);			}
		}		break;
		case 1: // Centre biased
			for (s = 0; s < R.SW.S; s++)   
		{
			for (d = 0; d < pb.SS.D; d++)  			{  				zz=0.5*(pb.SS.max[d]+pb.SS.min[d]);				if(alea(0,1)<0.5) R.SW.X[s].x[d]=zz*pow(alea(0,1),1./pb.SS.D);				else R.SW.X[s].x[d]=zz*(2-pow(alea(0,1),1./pb.SS.D));			}

		}		break;		case 2: // Improved Hammersley
			deb=alea_integer(0,pb.SS.D-1);

		for (s = 0; s < R.SW.S; s++)   
		{			R.SW.X[s]=hammersley(pb.SS,R.SW.S, deb,s);
			R.SW.X[s] = quantis (R.SW.X[s], pb.SS);
		}		break;		case 3: // Random or Improved Hammersley	
			deb=alea_integer(0,pb.SS.D-1);
		for (s = 0; s < R.SW.S; s++)   
		{			if(alea(0,1)<0.5)
			{				R.SW.X[s]=hammersley(pb.SS,R.SW.S, deb,s);
				R.SW.X[s] = quantis (R.SW.X[s], pb.SS);
			}			else				for (d = 0; d < pb.SS.D; d++)  			{  				R.SW.X[s].x[d] = alea (pb.SS.min[d], pb.SS.max[d]);			}
		}		break;

		case 5: // Centre biased 2
			for (s = 0; s < R.SW.S; s++)   
		{			for (d = 0; d < pb.SS.D; d++)  			{  				z=0.5*(pb.SS.min[d]+pb.SS.max[d]); // centre
				zz=alea (0, 1)-0.5; // Normalised distance to the centre
				zzz=(pb.SS.max[d]-pb.SS.min[d])*pow(fabs(zz),1+1./R.SW.S); // decrease it

				if(zz>0)					R.SW.X[s].x[d]=z+zzz; // re-add it
				else
					R.SW.X[s].x[d]=z-zzz;			}
		}		break;	}	// Velocity
	switch(param.initVel)
	{
		case 0:
			for (s = 0; s < R.SW.S; s++) // 1, 0.5 
		{	
			for (d = 0; d < pb.SS.D; d++)  			{								R.SW.V[s].v[d] =					alea (pb.SS.min[d], pb.SS.max[d])-alea (pb.SS.min[d], pb.SS.max[d]);			}
		}
			break;

			case 1: // Diff
			case1:
			for (s = 0; s < R.SW.S; s++)   // alea - xj
		{				s1=alea_integer(0,R.SW.S-1);
			for (d = 0; d < pb.SS.D; d++)  
			{  
				R.SW.V[s].v[d] =alea(pb.SS.min[d], pb.SS.max[d])-R.SW.X[s].x[d];			}
		}
			break;

		case 2:
		case2:
			for (s = 0; s < R.SW.S; s++)   // xi - xj
		{				s1=alea_integer(0,R.SW.S-1);
			for (d = 0; d < pb.SS.D; d++)  
			{  
				R.SW.V[s].v[d] =R.SW.X[s1].x[d]-R.SW.X[s].x[d];			}
		}
			break;

		case 3:
			for (s = 0; s < R.SW.S; s++)  // 0  
		{	
			for (d = 0; d < pb.SS.D; d++)  			{								R.SW.V[s].v[d] = 0;			}
		}
			break;

		case 4:
			if(alea(0,1)<0.5) goto case1; else goto case2;

			case 5: // Half-diff  0.5*(alea-x)
				for (s = 0; s < R.SW.S; s++)  
		{	
			for (d = 0; d < pb.SS.D; d++)  			{								R.SW.V[s].v[d] =					(alea (pb.SS.min[d], pb.SS.max[d])-R.SW.X[s].x[d])/2;			}
		}
			break;

			case 6: // Half-diff 0.5*(alea - alea)
				for (s = 0; s < R.SW.S; s++) // 1, 0.5 
		{	
			for (d = 0; d < pb.SS.D; d++)  			{								R.SW.V[s].v[d] =					0.5*(alea (pb.SS.min[d], pb.SS.max[d])-alea (pb.SS.min[d], pb.SS.max[d]));			}
		}
			break;
	}

		if(param.init==-1) fclose (f_init);

		// Distribution method(s)
		switch(param.R)
	{
		default:
			for (s = 0; s < R.SW.S; s++)  R.SW.R[s] =param.R;
			break;

		case 3:
			for (s = 0; s < R.SW.S; s++)
		{
			if(alea(0,1)<0.5 ) R.SW.R[s]=0; // Uniform
			else R.SW.R[s]=2; //  Decreasing function of the 1D distance
		}
			break;

		case 5:
			for (s = 0; s < R.SW.S; s++)
		{
			if(alea(0,1)<0.5 ) R.SW.R[s]=0; // Uniform
			else R.SW.R[s]=4; // The evaluation will be "smoothed" (method 1)
		}

		case 7:
			for (s = 0; s < R.SW.S; s++)
		{
			if(alea(0,1)<0.5 ) R.SW.R[s]=0; // Uniform
			else R.SW.R[s]=6; // The evaluation will be "smoothed" (method 2)
		}
			break;
	}

		// Strategies (different w)
		switch(param.strat)
	{
		default: // Constant w and c
			for (s = 0; s < R.SW.S; s++)   
		{
			R.SW.w[s]=param.w[0];
			R.SW.c[s]=param.c1;
		}
		break;
		case 1: // Random w (uniform) for some particles
			for (s = 0; s < R.SW.S; s++)   
		{
			if(alea(0,1)<param.w0Rate)
				R.SW.w[s]=param.w[0]; 
			else R.SW.w[s]=param.w[1];

			R.SW.c[s]=param.c1;
		}
		break;

		case 2: // Random w (non-uniform) for some particles
			for (s = 0; s < R.SW.S; s++)   
		{
			if(alea(0,1)<param.w0Rate) R.SW.w[s]=param.w[0]; 
			else
			{
				R.SW.w[s]=
					(alea(0,1)+alea(0,1))*(param.w[1]-param.w[0])+2*param.w[0]-param.w[1];
			}
			R.SW.c[s]=param.c1;
		}
		break;

		case 3: // Random w (uniform) for all particles
			zz=param.w[0]*0.5;
		zzz=zz+0.5;
		for (s = 0; s < R.SW.S; s++)   
		{ 
			R.SW.w[s]=alea(zz,zzz);
			R.SW.c[s]=param.c1;
			//R.SW.c[s]=pow(R.SW.w[s]+1,2)*0.5;
		}
		break;

		case 4: // Forced "scout" particle(s)
			m=1;
		for (s = 0; s < m; s++)   
		{
			R.SW.w[s]=alea(param.w[0],param.w[1]); 
			R.SW.c[s]=param.c1;
		}

		for (s = m; s < R.SW.S; s++)   
		{
			R.SW.w[s]=param.w[0];
			R.SW.c[s]=param.c1; 
		}
		break;
	}

		if(param.R==7) // Adaptive quantisation
	{
		qAdapt=quantAdapt(R.SW, pb);
	}

		// Take quantisation into account
		for (s = 0; s < R.SW.S; s++) 
	{	
		if(param.R==7) 
		{
			zz=((double)(pb.evalMax-R.nEval))/pb.evalMax;
			zz=zz*zz;
			if(alea(0,1)<zz) R.SW.R[s]=6;
			else R.SW.R[s]=0;
		}


		if(R.SW.R[s]==6) // Modify the quantisation
		{
			qTemp=pb.SS.q;
			pb.SS.q=qAdapt;
		}

		R.SW.X[s] = quantis (R.SW.X[s], pb.SS);

		if(R.SW.R[s]==6)  // Restore the quantisation
		{
			pb.SS.q=qTemp;
		}
	}

		// First evaluations
		for (s = 0; s < R.SW.S; s++) 
	{			R.SW.X[s].f =
			perf (R.SW.X[s], pb, 0, 0, 0);
		R.SW.P[s] = R.SW.X[s];	// Best position = current one
		R.SW.P[s].improved = 0;	// No improvement
		R.SW.XPrev[s]=R.SW.X[s];	}
		// If the number max of evaluations is smaller than 		// the swarm size, just keep evalMax particles, and finish		if (R.SW.S>pb.evalMax) R.SW.S=pb.evalMax;			R.nEval = R.SW.S;

		// Find the best and the worst		// 	Remember that f is fabs(fitness-objective)		// 	We want to minimise it		R.SW.best = 0;
		R.SW.worst=0;		errorPrev = R.SW.P[R.SW.best].f;		for (s = 1; s < R.SW.S; s++)     	{		zz=R.SW.P[s].f;		if (zz < errorPrev)		{			R.SW.best = s;			errorPrev=zz;			}
		if(zz>R.SW.P[R.SW.worst].f) R.SW.worst=s;	}
		errorInit=errorPrev; // Just for information
		error=errorPrev;


		// Display the best
		printf( "\n Best value after init. %f ", errorPrev );
fprintf(f_run,"\n Best value after init. %f ", errorPrev );
		// Uncomment this in order to display the position
		//printf( "\n Position :\n" );
		//for ( d = 0; d < pb.SS.D; d++ ) printf( " %f", R.SW.P[R.SW.best].x[d] );

		initLinks = 1;		// So that information links will beinitialized
		// Note: It is also a flag saying "No improvement"
		switch(param.initLinkNbMax)
	{
		default:initLinkNbMax=param.initLinkNbMax;
		break;
		case 0: initLinkNbMax=R.SW.S/2;
		break;
		case -1:    initLinkNbMax=2; //(int)(0.5/param.p);
		break;
	}
		initLinkNb=0; // Number of iterations without checking if structural adaptation
		// is needed
		errorI=errorPrev;
		noStop=0;		iter=0; iterBegin=0;		rho=param.size_LEA;		explRate=param.force_LEA;		// ---------------------------------------------- ITERATIONS
		while (noStop == 0) 
	{
		//printf("\niter %i",iter); 		iter=iter+1;		if (initLinks==1)	// Random topology
		{

			// Who informs who, at random
			for (s = 0; s < R.SW.S; s++)
			{					for (m = 0; m < R.SW.S; m++)				{	    					if (alea (0, 1)<p) LINKS[m][s] = 1;	// Probabilistic method					else LINKS[m][s] = 0;				}
			}			// Each particle informs itself			for (m = 0; m < R.SW.S; m++)			{
				LINKS[m][m] = 1;	     			}	  		}

		// Prepare the move
		//printf("\nIteration %i",iter);		for (s = 0; s < R.SW.S; s++)		{  			index[s]=s;			R.SW.Pp[s] = R.SW.P[s]; // Save the previous best, for information			R.SW.lBest[s]=0; // Initialise the flags (for information)			R.SW.X[s].forced=0; // Non "forced" move (for the moment)			R.SW.P[s].forced=0;		}		explForced=0; // In order the evaluate the exploitation rate				switch (param.randOrder)		{			default:				break;				case 1: //Define a random permutation					length=R.SW.S;				for (s=0;s<length;s++) indexTemp[s]=index[s];				for (s=0;s<R.SW.S;s++)			{				rank=alea_integer(0,length-1);				index[s]=indexTemp[rank];				if (rank<length-1)	// Compact				{					for (t=rank;t<length;t++)						indexTemp[t]=indexTemp[t+1];				}									length=length-1;			}				break;					}
		for (s0 = 0; s0 < R.SW.S; s0++)	// For each particle ...
		{				s=index[s0];
			// ... find the first informant
			s1 = 0;    			while (LINKS[s1][s] == 0)	s1++;								if (s1 >= R.SW.S)	{s1 = s;} // If no informant at all, just himself			else
			{				// Find the best informant							g[s] = s1;					for (m = s1; m < R.SW.S; m++) 				{	    					if (LINKS[m][s] == 1 && R.SW.P[m].f < R.SW.P[g[s]].f)						g[s] = m;				}
			}				R.SW.lBest[g[s]]=1; // Particle g[s] is a best informant		}		// Find the best of the best of all informants		sBest=0;		for (s = 1; s < R.SW.S; s++)		{				if(R.SW.P[g[s]].f < R.SW.P[g[sBest]].f) sBest=s;		}		// Define the exploitation area

		switch(param.explOption)
		{
			default: break;
			case 1: // Variable. TO DO

				break;
			case 2: // Variable. TO DO

				break;
			case 3:
				if(alea(0,1)<0.5) rho=param.size_LEA;  else rho=1./param.S;
				break;
			case 4:
				rho=alea(0,param.size_LEA);
				break;
			case 5:
				rho=fabs(alea_normal(1./param.S,param.size_LEA));
				break;
		}		ex=exploitArea(R.SW, pb.SS,rho); 		// For information, compute the size of the best local area		explBestSize=1;		for(d=0;d<pb.SS.D;d++)
		{			explBestSize=				explBestSize*(ex.exI[g[sBest]].max[d]-ex.exI[g[sBest]].min[d]);
		}		fprintf(f_expl, "explBestSize %f ",explBestSize);		// When the position is "forced", theoretically speaking the velocity		// of the particle should be also modified		// However, in practice, it appears it does not make any difference		switch(param.choose_LEA)		{			case 0: // Nothing special				break;			case 1: // LEA of some particles
				if(alea(0,1)>param.force_LEA) continue;
			switch(param.draw_LEA)
			{
				case 0: // middle of the LEA
					case 3: // and also uniform 
					if(R.SW.P[g[s]].forced==1) continue; // No need to choose the 				//middle several times!				explForced=explForced+1;				for (d = 0; d < pb.SS.D; d++)				{								local.x[d]=						0.5*(ex.exI[g[s]].max[d]+ex.exI[g[s]].min[d]);				}				local = quantis (local, pb.SS);				local.f =perf(local,pb,0,0,0);				R.nEval = R.nEval + 1;				if(local.f<R.SW.X[s].f)				{					R.SW.X[s]=local;					R.SW.X[s].forced=1;					R.SW.P[g[s]].forced=1;				}

				if(param.draw_LEA==0) break;

				case 1: // Uniform					for (s = 0; s < R.SW.S; s++)	// For each particle ...				{						explForced=explForced+1;					for (d = 0; d < pb.SS.D; d++)					{									local.x[d]=ex.exI[g[s]].min[d]+							alea(0,1)*(ex.exI[g[s]].max[d]-ex.exI[g[s]].min[d]);					}					local = quantis (local, pb.SS);					local.f =perf(local,pb,0,0,0);					R.nEval = R.nEval + 1;					if(local.f<R.SW.X[s].f)					{						R.SW.X[s]=local;						R.SW.X[s].forced=1;					}				}				break;
				case 2: // Gaussian
					s=g[sBest];				if(R.SW.P[g[s]].forced==1) break; // Already done				explForced=explForced+1;				for (d = 0; d < pb.SS.D; d++)				{								zz=0.5*(ex.exI[g[sBest]].max[d]-ex.exI[g[sBest]].min[d]);					zzz=alea_normal(0,1.48*zzz); // For a fifty-fifty probability distribution					if(fabs(zzz)>zz) 					{ if (zzz>0) zzz=zz; else zzz=-zz;};					local.x[d]=						zzz+0.5*(ex.exI[g[sBest]].max[d]+ex.exI[g[sBest]].min[d]);				}				local = quantis (R.SW.X[s], pb.SS);				local.f =perf(R.SW.X[s],pb,0,0,0);				R.nEval = R.nEval + 1;				if(local.f<R.SW.X[s].f)				{					R.SW.X[s]=local;					R.SW.X[s].forced=1;				}

				break;

			} // End of switch draw_LEA
			break;
			case 2: // In the best local area
				switch(param.draw_LEA)
			{
				case 0: // middle
					case 3: // and also uniform
					if(R.SW.P[g[sBest]].forced==1) continue; // No need to choose the 				//middle several times!				explForced=explForced+1;				for (d = 0; d < pb.SS.D; d++)				{								local.x[d]=						0.5*(ex.exI[g[sBest]].max[d]+ex.exI[g[sBest]].min[d]);				}				local = quantis (local, pb.SS);				local.f =perf(local,pb,0,0,0);				R.nEval = R.nEval + 1;				if(local.f<R.SW.X[s].f)				{					R.SW.X[s]=local;					R.SW.X[s].forced=1;					R.SW.P[g[sBest]].forced=1;				}

				if(param.draw_LEA==0) break;

				case 1: // At random uniform					for (s = 0; s < R.SW.S; s++)	// For each particle ...				{					if(alea(0,1)>param.force_LEA) continue;// ... may or may not be forced					explForced=explForced+1;					for (d = 0; d < pb.SS.D; d++)					{									local.x[d]=ex.exI[g[sBest]].min[d]+							alea(0,1)*(ex.exI[g[sBest]].max[d]-ex.exI[g[sBest]].min[d]);					}					local = quantis (local, pb.SS);					local.f =perf(local,pb,0,0,0);					R.nEval = R.nEval + 1;					if(local.f<R.SW.X[s].f)					{						R.SW.X[s]=local;						R.SW.X[s].forced=1;					}				}				break;

				case 2: // random, Gaussian
					s=g[sBest];				if(R.SW.P[g[s]].forced==1) break; // Already done				explForced=explForced+1;				for (d = 0; d < pb.SS.D; d++)				{								zz=0.5*(ex.exI[g[sBest]].max[d]-ex.exI[g[sBest]].min[d]);					zzz=alea_normal(0,1.48*zzz); // For a fifty-fifty probability distribution					if(fabs(zzz)>zz) 					{ if (zzz>0) zzz=zz; else zzz=-zz;};					local.x[d]=						zzz+0.5*(ex.exI[g[sBest]].max[d]+ex.exI[g[sBest]].min[d]);				}				local = quantis (R.SW.X[s], pb.SS);				local.f =perf(R.SW.X[s],pb,0,0,0);				R.nEval = R.nEval + 1;				if(local.f<R.SW.X[s].f)				{					R.SW.X[s]=local;					R.SW.X[s].forced=1;				}

				break;
			} // End of switch draw_LEA
		} // End of switch choose_LEA		//** Move, for non "forced" particles =====================
		if(param.R==7) // Adaptive quantisation
		{
			qAdapt=quantAdapt(R.SW, pb);
		}
		for (s0 = 0; s0 < R.SW.S; s0++)	// For each particle ...		{				s=index[s0];			if(R.SW.X[s].forced==1) goto update_best;			// Exploration tendency

			// if(R.SW.XPrev[s].f>R.SW.X[s].f) vDamp=0; // If improvement, slow down
			// else vDamp=1;

			for (d = 0; d < pb.SS.D; d++)			{				R.SW.V[s].v[d]=vDamp*R.SW.w[s]*R.SW.V[s].v[d];			}
			// Prepare Exploitation tendency			for (d = 0; d < pb.SS.D; d++) // p-x			{				PX.v[d]= R.SW.P[s].x[d] - R.SW.X[s].x[d];			}							PX.size=pb.SS.D; 			if(g[s]!=s)			{				for (d = 0; d < pb.SS.D; d++) // g-x				{					GX.v[d]= R.SW.P[g[s]].x[d] - R.SW.X[s].x[d];				}				GX.size=pb.SS.D;			}			// Exploitation tendencies
			c1=R.SW.c[s];
			c2=c1;			switch(R.SW.R[s])			{							default:					for (d = 0; d < pb.SS.D; d++)				{						R.SW.V[s].v[d]=R.SW.V[s].v[d] +						+	alea(0, c1)*PX.v[d];				}					if (g[s]!=s) // If the best neighbour is not the particle itself				{					for (d = 0; d < pb.SS.D; d++)					{							R.SW.V[s].v[d]=R.SW.V[s].v[d] 							+	alea(0,c2) * GX.v[d];								}				}					break;					case 1:							for (d = 0; d < pb.SS.D; d++)				{						R.SW.V[s].v[d]=R.SW.V[s].v[d] +						+	c1*alea_normal(alea(0,1), param.sigma)*PX.v[d];				}					if (g[s]!=s)				{					for (d = 0; d < pb.SS.D; d++)					{							R.SW.V[s].v[d]=R.SW.V[s].v[d] 							+	c2*alea_normal(alea(0,1), param.sigma) * GX.v[d];								}				}					break;

				case 2: 
					for (d = 0; d < pb.SS.D; d++) // idem "default"				{						R.SW.V[s].v[d]=R.SW.V[s].v[d] +	c1*alea(0, 1)*PX.v[d];				}					if (g[s]!=s) // If the best neighbour is not the particle itself				{					for (d = 0; d < pb.SS.D; d++) // Distance decreasing					{							zz=fabs(GX.v[d])/(pb.SS.max[d]-pb.SS.min[d]);// Relative distance
						zzz=(1-zz); 
						R.SW.V[s].v[d]=R.SW.V[s].v[d] 							+	c2*alea(0,1) *pow(zzz,distPow) *GX.v[d];								}				}
					break;			}			// Update the position			for (d = 0; d < pb.SS.D; d++)			{					R.SW.X[s].x[d] = R.SW.X[s].x[d] + R.SW.V[s].v[d];						}			if (R.nEval >= pb.evalMax) goto end;				
			// --------------------------
			noEval = 1;

			if(param.R==7) 
			{
				zz=exp(-param.S*(double)R.nEval/pb.evalMax);
				if(alea(0,1)<zz) R.SW.R[s]=6;
				else R.SW.R[s]=0;
			}


			// Take quantisation into account
			if(R.SW.R[s]==6) // Modify the quantisation
			{
				qTemp=pb.SS.q;
				pb.SS.q=qAdapt;
			}

			R.SW.X[s] = quantis (R.SW.X[s], pb.SS);

			if(R.SW.R[s]==6)  // Restore the quantisation
			{
				pb.SS.q=qTemp;
			}
			switch (param.clamping)			{							case 0:	// No clamping AND no evaluation if outside					outside = 0;				for (d = 0; d < pb.SS.D; d++)				{								if (R.SW.X[s].x[d] < pb.SS.min[d] || R.SW.X[s].x[d] > pb.SS.max[d])						outside++;								}				if (outside == 0)	// If inside, the position is evaluated				{							R.SW.X[s].f =						perf (R.SW.X[s], pb,R.SW.R[s], param.aroundNb, param.S);										R.nEval = R.nEval + 1;	
					if(R.SW.R[s]==4) R.nEval=R.nEval+param.aroundNb;											}								break;				case 1:	// Set to the bounds, and v to zero
					outside=0;				for (d = 0; d < pb.SS.D; d++)				{						if (R.SW.X[s].x[d] < pb.SS.minS[d])					{							R.SW.X[s].x[d] = pb.SS.minS[d];						R.SW.V[s].v[d] = 0;
						if(pb.SS.minS[d]<pb.SS.min[d]-zero) outside++;					}					if (R.SW.X[s].x[d] > pb.SS.maxS[d])					{									R.SW.X[s].x[d] = pb.SS.maxS[d];						R.SW.V[s].v[d] = 0;
						if(pb.SS.maxS[d]>pb.SS.max[d]+zero) outside++;								}							}
				if(outside==0)
				{								R.SW.X[s].f =perf(R.SW.X[s],pb,R.SW.R[s], param.aroundNb, param.S);					R.nEval = R.nEval + 1;
					if(R.SW.R[s]==4) R.nEval=R.nEval+param.aroundNb;
				}					break;						}	

			update_best:
				// ... update the best previous position
				if (R.SW.X[s].f < R.SW.P[s].f)	// Improvement
			{		
				R.SW.P[s] = R.SW.X[s];	 		
				// ... update the best of the bests
				if (R.SW.P[s].f < R.SW.P[R.SW.best].f)
				{							R.SW.best = s;							}							}

				// Save the previous position
				R.SW.XPrev[s]=R.SW.X[s];

				if(param.opposite==1)
			{
				// Update the worst
				if (R.SW.P[s].f > R.SW.P[R.SW.worst].f)
				{							R.SW.worst = s;							}				
			}			}			// End of "for (s0=0 ...  "	
		if(param.opposite==1)
		{
			// Move the worst (Opposite)
			for (d = 0; d < pb.SS.D; d++)			{					R.SW.X[R.SW.worst].x[d] = pb.SS.minS[d]+pb.SS.maxS[d]-R.SW.X[R.SW.worst].x[d];
				R.SW.V[R.SW.worst].v[d]=-	R.SW.V[R.SW.worst].v[d];			}	
			R.SW.P[R.SW.worst]=R.SW.X[R.SW.worst];
			// Note that the fitness is wrong (not re-evaluated here)
		}		explRate0=explRate;		explRate=explNb(R.SW,ex); // Exploitation rate		// WARNING: count only "successful" moves		/*		 // The following count takes into account all particles that have been		 // forced into a local area, even if the final position		 // has not been kept (unsuccessful)		 explRate=(double)explForced/R.SW.S;		 fprintf(f_expl,"%f\n",explRate);		 */		// Modify the future size of the local area		// in order to "balance" exploitation/exploration		switch(param.explOption)		{			default: // Keep constant *				break;			case 1:				rho=pow(pow(rho,pb.SS.D)+explRate-explRate0,1./pb.SS.D);				break;			case 2:				if(explRate-explRate0>0)			{				rho=rho*pow( 1-(explRate-explRate0)/(1-explRate0),1./pb.SS.D);			}				else			{				rho=pow(pow(rho,pb.SS.D) + 				        (explRate-explRate0)*(pow(rho,pb.SS.D)-1)/explRate0,1./pb.SS.D);			}				break;			case 3:				if(alea(0,1)<0.5) rho=param.size_LEA;				else rho=1./param.S;				break;				case 4: // Random Uniform					rho=alea(0,param.size_LEA);				break;				//	case 5: // Random Gauss				rho=fabs(alea_normal(0,param.size_LEA)); 				if (rho>1)  rho=1;				break;		}		//printf("\nExploitation rate %f",explRate); 

		initLinkNb=initLinkNb+1;
		initLinks=0;
		if(initLinkNb>=initLinkNbMax)
		{			initLinkNb=0;
			// Check if improvement since last structural adaptation						error = R.SW.P[R.SW.best].f;
			if (error < errorPrev)	// Improvement
			{						initLinks = 0;										}
			else			// No improvement
			{							initLinks = 1;	// Information links will be	reinitialized				}

			if(param.initLink==1) initLinks=1-initLinks;
			errorI=error;
			errorPrev = error;
		}	

		end:

			// Prepare the curve "success rate" vs FEmax
			if(error<=pb.epsilon) 
		{				
			for(n=FEclass;n<FEmaxSize;n++)
				successFlag[run][n]=1;
		}

			if(R.nEval>FEmax[FEclass])
		{
			// Prepare the curve "mean best" vs FEmax
			best[run][FEclass]=error;	
			FEclass=FEclass+1;
		}
			switch (param.stop)
		{					case 0:				if (error > pb.epsilon && R.nEval < pb.evalMax)
					noStop = 0;	// Won't stop
				else
					noStop = 1;	// Will stop
				break;
			case 1:							if (R.nEval < pb.evalMax)
					noStop = 0;	// Won't stop
				else
					noStop = 1;	// Will stop
				break;				}

			if(noStop==0 && param.select>0) // Reinitialise bad particles
		{
			// Sort the particles according to the fitness
			for (s = 0; s < n; s++) sF[s].s=s; sF[s].f=R.SW.X[s].f;
			qsort(sF,R.SW.S,sizeof(sF[0]),compareF);


			// Reinitialise the select*S first ones
			n=param.select*R.SW.S;

			for (s = 0; s < n; s++)   
			{					for (d = 0; d < pb.SS.D; d++)  
				{  
					R.SW.X[sF[s].s].x[d] = alea (pb.SS.min[d], pb.SS.max[d]);
					R.SW.V[sF[s].s].v[d]=0;				}
			}
		}

	} // End of "while nostop ...

		R.convRate=(errorInit-error)/errorInit;		R.error = error;		return R;  }


// ===========================================================
double alea (double a, double b) 
{				// random number (uniform distribution) in  [a b]
	// randOption is a global parameter (see also param.rand)
	double r;
	if(randOption==0) 
		r=a+(double)rand_kiss()*(b-a)/RAND_MAX_KISS;
	else 
		r=a + (double) rand () * (b - a)/RAND_MAX; 
	return r; }

// ===========================================================
int alea_integer (int a, int b) 
{				// Integer random number in [a b]
	int ir;
	double r;
	r = alea (0, 1);
	ir = (int) (a + r * (b + 1 - a));
	if (ir > b)	ir = b;   	return ir;  }

// ===========================================================
double alea_normal (double mean, double std_dev) 
{ 
	/*
	 Use the polar form of the Box-Muller transformation to obtain a pseudo	 random number from a Gaussian distribution 
	 */ 
	double x1, x2, w, y1;  
	// double y2;

	do  
	{		x1 = 2.0 * alea (0, 1) - 1.0;		x2 = 2.0 * alea (0, 1) - 1.0;		w = x1 * x1 + x2 * x2;     	}
	while (w >= 1.0);
	w = sqrt (-2.0 * log (w) / w);
	y1 = x1 * w;
	// y2 = x2 * w;	if(alea(0,1)<0.5) y1=-y1; 
	y1 = y1 * std_dev + mean;
	return y1;  }

//================================================static int compareF (void const *a, void const *b){	// For qsort (increasing order of fitness)	struct sF const *pa = a;	struct sF const *pb = b;	if(pa->f > pb->f) return -1;	if(pa->f < pb->f) return 1;	return 0;}
//================================================static int compareLBest (void const *a, void const *b){	// For qsort (increasing order)	struct lBest const *pa = a;	struct lBest const *pb = b;	// NOTE: needs the global variable dLBest	if(pa->x[dLBest] > pb->x[dLBest]) return 1;	if(pa->x[dLBest] < pb->x[dLBest]) return -1;	return 0;}
//============================================================struct exploit exploitArea(struct swarm SW, struct SS SS, double rho){	// Define the exploitation area	int d;	struct exploit ex; // local search space (D, max, min, quantum)	// around each local best	int i;	struct lBest lB[SMax+2];  	int nbLBest; // Number of different local bests	//double rho; // Define what "around" means. Should be <= 0.5	int s;	//printf("\nExploitation area with rho=%f",rho);	/*	 For each local best, define the local exploitation area (LEA)	 (hyperparallelepid "around" it.	  */	// Build the list of local bests (index, coordinates) + min + max	i=1;	for(s=0;s<SW.S;s++)	{		if(SW.lBest[s]==0) continue;		lB[i].rank=s;		for (d=0;d<SS.D;d++) lB[i].x[d]=SW.Pp[s].x[d];		i=i+1;	}	lB[0].rank=-1; // "Left" border point	lB[i].rank=-2; // "Right" border point	for (d=0;d<SS.D;d++) 	{		lB[0].x[d]=SS.min[d];		lB[i].x[d]=SS.max[d];	}	nbLBest=i-2; // Number of local bests	// For each dimension	// Sort the list 	// Define the intervals	for(d=0;d<SS.D;d++)	{		// Sort the list by ascending order		dLBest=d; // Global variable. Needed for compareLBest		qsort(lB,nbLBest+2,sizeof(lB[0]),compareLBest);		// For each local best		// add the interval in dimension d that defines the LEA		for (i=0;i<SW.S;i++) 		{			ex.rank[i]=0; // Means N/A			ex.exI[i].D=SS.D; // For future use (local search)			ex.exI[i].q.size=SS.D; // "		}		for (i=1;i<nbLBest+2;i++)		{					ex.rank[lB[i].rank]=1;			ex.exI[lB[i].rank].min[d]=lB[i].x[d]-rho*(lB[i].x[d]-lB[i-1].x[d]);  			ex.exI[lB[i].rank].max[d]=lB[i].x[d]+rho*(lB[i+1].x[d]-lB[i].x[d]);			ex.exI[lB[i].rank].q.q[d]=SS.q.q[d];		}	}	return ex; }//==================================================double explNb(struct swarm SW, struct exploit ex ){	// For each position	// check if it is inside a LEA	int d;	int Dim;	int exNb=0;	double rate;	int i;	int inExArea;	int s;	Dim=ex.exI[0].D;	for (s=0;s<SW.S;s++) // For each position	{			for(i=0;i<SW.S;i++) // For each "exploitation area" (hyperparallelepid)		{			if(ex.rank[i]<=0) continue;			inExArea=1;			for(d=0;d<Dim;d++) // For each "exploitation interval"			{				if(SW.X[s].x[d]<=ex.exI[i].min[d] || SW.X[s].x[d]>= ex.exI[i].max[d])				{inExArea=0; break;}					}			if(inExArea==1)			{				exNb=exNb+1;				break; // Counted just once			}		}	}	rate=(double)exNb/SW.S;	fprintf(f_expl,"%f\n",rate); // Rate of particles that "exploit"	return rate;}//==================================================struct position hammersley(struct SS SS, int N, int deb, int s){	struct position x;	double a;	int d,D;	int dd;	int  kp;	int pp;	D=SS.D;	// A sequence of prime numbers. You may modify it	int P[100]={2,3,5,7,11, 13, 17, 19, 23, 29,		31, 37, 41, 43, 47, 53, 59, 61, 67, 71,		73,79,83,89,97,101,103,107,109,113,		127,131,137,139,149,151,157,163,167,173,		179, 181,191,193,197,199,211,223,227,229,		233,239,241,251,257,263,269,271,277,281,		283,293,307,311,313,317,331,337,347,349,		353,359,367,373,379,383,389,397,401,409,		419,421,431,433,439,443,449,457,461,463,		467,479,487,491,499,503,509,521,523,541	}; 	double z;
	if(D>100) 
	{
		printf("\nDimension D = %i is too high\n",D);
		ERROR("You must increase the list of prime numbers");
	}
	x.size=D;	x.x[deb]=SS.min[deb]+(SS.max[deb]-SS.min[deb])*(double)s/(N-1);
	dd=deb;	for(d=1;d<D;d++) // for each dimension	{				// compute the position		dd=dd+1; if(dd>=D) dd=0;		pp=P[dd];		kp=s+1;		z=0;		while (kp>0)		{			a=kp % P[dd];     // kp modulo P[dd]			z=z+(double)a/pp;			kp=kp/P[dd]; // Integer division			pp=pp*P[dd];		}		x.x[dd]=SS.min[dd]+z*(SS.max[dd]-SS.min[dd]);
	}	return x;}//================================================== KISS/* A good pseudo-random numbers generator The idea is to use simple, fast, individually promising generators to get a composite that will be fast, easy to code have a very long period and pass all the tests put to it. The three components of KISS are x(n)=a*x(n-1)+1 mod 2^32 y(n)=y(n-1)(I+L^13)(I+R^17)(I+L^5), z(n)=2*z(n-1)+z(n-2) +carry mod 2^32 The y's are a shift register sequence on 32bit binary vectors period 2^32-1; The z's are a simple multiply-with-carry sequence with period 2^63+2^32-1.  The period of KISS is thus 2^32*(2^32-1)*(2^63+2^32-1) > 2^127 */static ulong kiss_x = 1;static ulong kiss_y = 2;static ulong kiss_z = 4;static ulong kiss_w = 8;static ulong kiss_carry = 0;static ulong kiss_k;static ulong kiss_m;void seed_rand_kiss(ulong seed) {	kiss_x = seed | 1;	kiss_y = seed | 2;	kiss_z = seed | 4;	kiss_w = seed | 8;	kiss_carry = 0;}ulong rand_kiss() {	kiss_x = kiss_x * 69069 + 1;	kiss_y ^= kiss_y << 13;	kiss_y ^= kiss_y >> 17;	kiss_y ^= kiss_y << 5;	kiss_k = (kiss_z >> 2) + (kiss_w >> 3) + (kiss_carry >> 2);	kiss_m = kiss_w + kiss_w + kiss_z + kiss_carry;	kiss_z = kiss_w;	kiss_w = kiss_m;	kiss_carry = kiss_k >> 30;	return kiss_x + kiss_y + kiss_w;}
// ===========================================================
int sign (double x) 
{     	//if (x == 0)	return 0; // Note that this is NOT the classical sign function
	if (x <= 0)	return -1;    	return 1;   }

// ===========================================================
struct position quantis (struct position x, struct SS SS) 
{     
	/*
	 Quantisation of a position	 Only values like x+k*q (k integer) are acceptable 
	 */ 
	int d;
	double qd;
	struct position quantx;
	quantx = x;     	for (d = 0; d < x.size; d++)
	{
		qd = SS.q.q[d];	
		if (qd > zero)	// Note that qd can't be < 0
		{     	      			quantx.x[d] = qd * floor (0.5 + x.x[d] / qd);	    		}	}	return quantx;    }
// ===========================================================
struct quantum quantAdapt(struct swarm SW, struct problem pb)
{
	struct quantum qAdapt;
	int d;
	double xMin, xMax;
	int s;
	int option=2; // Just for test purpose

	qAdapt.size=pb.SS.q.size;

	switch(option)
	{
		case 0:
			for (d = 0; d < pb.SS.D; d++) 
		{
			qAdapt.q[d]=0.01*(pb.SS.max[d]-pb.SS.min[d]);
		}
			break;

		case 2:
			for (d = 0; d < pb.SS.D; d++) 
		{
			qAdapt.q[d]=(pb.SS.max[d]-pb.SS.min[d])/pow(2,(double)iter/SW.S);
		}

		case 1:
			qAdapt=pb.SS.q;
			for (d = 0; d < pb.SS.D; d++)  // On each dimension
				// find the min and max position 		{
			xMin= SW.X[0].x[d];
			xMax= SW.X[0].x[d];		
			for(s=1;s < SW.S; s++)
			{
				if(SW.X[s].x[d]<xMin) xMin=SW.X[s].x[d];
				if(SW.X[s].x[d]>xMax) xMax=SW.X[s].x[d];
			}

			qAdapt.q[d]=0.5*(xMax-xMin)/(SW.S+1);
			if(pb.SS.q.q[d]>zero) // There is already a quantum
				// The new one must be k (integer) times the previous one
			{
				qAdapt.q[d]=pb.SS.q.q[d]+(int)(qAdapt.q[d]/pb.SS.q.q[d]);
			}
		}
			break;
	}
	return qAdapt;
}

// ===========================================================
double perf (struct position x, struct problem pb, int option, int aroundNb, int SwarmSize) 
{				// Evaluate the fitness value for the particle of rank s 
	struct position around[DMax+1];
	double c;
	int d;	double DD;
	int deb;
	double dx1,dx2;
	int grid;
	int  i,j,k;
	double f=0;
	double p;	double s11, s12, s21, s22;	double sum1,sum2;
	struct SS SSaround;
	double t0, tt, t1;
	double x1,x2,x3,x4;
	double xd;
	struct position xs;
	double y,y1,y2; 	double z,z2;	#include "cec2005data.c"

	// Variables specific to Coil compressing spring
	static double	Fmax=1000.0;
	static double	Fp=300;
	double Cf;
	double K;
	double sp;
	double lf;

	static double	S=189000.0;
	static double	lmax=14.0;
	static double	spm=6.0;
	static double	sw=1.25;
	static double	G=11500000;
	//----------------------------------------------------
	switch(option)
	{
		default: break;
		/*
		 case 4: // Simplified form, when using just two points
		 z=0.5*(pb.SS.max[d]-pb.SS.min[d])/(SwarmSize+1);
		 for (d=0;d<x.size;d++)
		 {


		 }
		 */
		case 4: // Do  not compute the fitness of the position x, but 
			// generate aroundNb points "around" x ...
			SSaround.D=x.size;
		for (d=0;d<x.size;d++) // Define the local domain
		{
			z=0.5*(pb.SS.max[d]-pb.SS.min[d])/(SwarmSize+1); // ???
			//z=(1./3)*(pb.SS.max[d]-pb.SS.min[d])/(SwarmSize+1); // ???
			SSaround.max[d]= x.x[d]+z; 
			if(SSaround.max[d]>pb.SS.max[d]) SSaround.max[d]=pb.SS.max[d];
			SSaround.min[d]= x.x[d]-z; 
			if(SSaround.min[d]<pb.SS.min[d]) SSaround.min[d]=pb.SS.min[d];

			SSaround.q.size=x.size;
			SSaround.q.q[d]=pb.SS.q.q[d];
			SSaround.maxS[d]=SSaround.max[d];
			SSaround.minS[d]=SSaround.min[d];
		}

		deb=alea_integer(0,aroundNb-1); // Improved Hammersley
		for (i = 0; i < aroundNb; i++)   
		{			around[i]=hammersley(SSaround,aroundNb, deb,i);
		}

		// ... and compute the mean of their fitnesses
		f=perf(x,pb,0,0,0);
		for(i=0;i<aroundNb;i++) f=f+perf(around[i],pb,0,0,0);

		return fabs(f/(aroundNb+1)-pb.objective);
	}

	xs = x;
	switch (pb.function)
	{#include "cec2005.c" // CEC 2005 benchmark

		case 0:		// Parabola (Sphere)
			f=0.;		for (d = 0; d < xs.size; d++) 
		{			xd = xs.x[d];    			f = f + xd * xd;    		}	
		break;
		case 1:		// Griewank
			f = 0; 		p = 1;
		for (d = 0; d < xs.size; d++)
		{      			xd = xs.x[d];
			//xd=xd-150;			f = f + xd * xd;	      			p = p * cos (xd / sqrt ((double) (d + 1)));	    		} 		f = f / 4000 - p + 1;	  		break;		case 2:		// Rosenbrock			f = 0;  		t0 = xs.x[0]  + 1;	// Solution on (0,...0) when
		// offset=0
		for (d = 1; d < xs.size; d++)
		{     			t1 = xs.x[d]  + 1;	      			tt = 1 - t0;	      			f += tt * tt;      			tt = t1 - t0 * t0;      			f += 100 * tt * tt;	      			t0 = t1;    		}  		break;		case 3:		// Rastrigin
			f=0;
		k = 10;  		for (d = 0; d < xs.size; d++)    
		{     			xd = xs.x[d];	      			f =f+ xd * xd - k * cos (2 * pi * xd);	    		}	  		f =f+ xs.size * k;  		break;
		case 4:		// 2D Tripod function
			// Note that there is a big discontinuity right on the solution
			// point. 	
			x1 = xs.x[0] ; 		x2 = xs.x[1];  		s11 = (1.0 - sign (x1)) / 2;
		s12 = (1.0 + sign (x1)) / 2; 		s21 = (1.0 - sign (x2)) / 2;
		s22 = (1.0 + sign (x2)) / 2;
		//f = s21 * (fabs (x1) - x2); // Solution on (0,0)		f = s21 * (fabs (x1) +fabs(x2+50)); // Solution on (0,-50)  		f = f + s22 * (s11 * (1 + fabs (x1 + 50) + fabs (x2 - 50)) 
		               + s12 * (2 +fabs (x1 - 50) + fabs (x2 - 50)));	  		break;		case 5:  // Ackley			sum1=0;		sum2=0;		DD=x.size;		pi=acos(-1);		for (d=0;d<x.size;d++)		{			xd=xs.x[d];			sum1=sum1+xd*xd;			sum2=sum2+cos(2*pi*xd);		}		f=-20*exp(-0.2*sqrt(  sum1/DD  ))-exp(sum2/DD)+20+exp(1);			break;


		case 7: // Pressure vessel 
			// Ref New Optim. Tech. in Eng. p 638
			// D = 4          
			x1=xs.x[0]; // [1.1,12.5] granularity 0.0625
		x2= xs.x[1];// [0.6,12.5] granularity 0.0625
		x3=xs.x[2]; // [0,240]
		x4= xs.x[3];// [0,240]

		f=0.6224*x1*x3*x4 + 1.7781*x2*x3*x3 + 3.1611*x1*x1*x4 +
			19.84*x1*x1*x3;

		// Constraints, by penalty method
		y=0.0193*x3-x1; if ( y>0) {c= 1+pow(10,10)*y;  f=f*c*c; }
		y=  0.00954*x3-x2; if (y>0) {c=1+y; f=f*c*c;  }
		y = 750*1728-pi*x3*x3*(x4+(4.0/3)*x3); 
		if (y>0) {c=1+y; f=f*c*c;  }
		break;

		case 8: // Coil compression spring 
			// Ref New Optim. Tech. in Eng. p 644

			x1=xs.x[0]; // {1,2, ... 70}
		x2= xs.x[1];//[0.6, 3]
		x3= xs.x[2];// relaxed form [0.207,0.5]  dx=0.001
		// In the original problem, it is a list of
		// acceptable values
		// {0.207,0.225,0.244,0.263,0.283,0.307,0.331,0.362,0.394,0.4375,0.5}

		f=pi*pi*x2*x3*x3*(x1+2)*0.25;

		// Constraints
		Cf=1+0.75*x3/(x2-x3) + 0.615*x3/x2;
		K=0.125*G*pow(x3,4)/(x1*x2*x2*x2);
		sp=Fp/K;
		lf=Fmax/K + 1.05*(x1+2)*x3;

		y=8*Cf*Fmax*x2/(pi*x3*x3*x3) -S;
		if (y>0) {c=1+y; f=f*c*c*c;}

		y=lf-lmax;
		if (y>0) {c=1+y; f=f*c*c*c;}

		y=sp-spm;
		if (y>0) {c=1+y; f=f*c*c*c;}

		y=sp-Fp/K;

		if (y>0) {c=1+pow(10,10)*y; f=f*c*c*c;}

		y=sw- (Fmax-Fp)/K;
		if (y>0) {c=1+pow(10,10)*y; f=f*c*c*c;}
		break;

		case 9: // Gear train
			x1=xs.x[0]; // {12,13, ... 60}
		x2= xs.x[1];// {12,13, ... 60}
		x3= xs.x[2];// {12,13, ... 60}
		x4= xs.x[3];// {12,13, ... 60}

		f=1./6.931 - x1*x2/(x3*x4);
		f=f*f;
		break;

#include "cellular_phone.c"

		case 12: // Schwefel
        f=418.98288727243369*pb.SS.D;
        for(d=0;d<pb.SS.D;d++)
        {
            xd=xs.x[d];
            f=f-xd*sin(sqrt(fabs(xd)));
        }
        break;

	}
	return fabs(f-pb.objective);}
//===================================================struct problem problemDef(int functionCode){	int d;	struct problem pb={0}; // Initialised just for my stupid compiler	pb.function=functionCode;		pb.epsilon = 0.00000;	//Default cceptable error	pb.objective = 0;       // Default objective value
	pb.SS.valueNb=0;	// Define the solution point, for test	// NEEDED when the stop criterion is distance_to_solution < epsilon	for (d=0; d<30;d++)	{		pb.solution.x[d]=0;	}	// ------------------ Search space	switch (pb.function)	{   #include "cec2005pb.c"
		case 0:			// Parabola			pb.SS.D =30;// Dimension		for (d = 0; d < pb.SS.D; d++)		{   			pb.SS.min[d] = -100; // -100			pb.SS.max[d] = 100;	// 100			pb.SS.q.q[d] = 0;	// granularity/quantum/step   1 => integer  
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 		}		pb.evalMax = 6000;//  Max number of evaluations for each run
		pb.epsilon = 0.0001;	// Acceptable error		pb.objective = 0;       // Objective value		break;		case 1:		// Griewank			pb.SS.D = 20;	   		// Boundaries		for (d = 0; d < pb.SS.D; d++) 		{				pb.SS.min[d] = -100; 			pb.SS.max[d] = 100; 			pb.SS.q.q[d] = 0;
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 		}		pb.evalMax = 9000;	  
		pb.epsilon = 0.0001;			pb.objective = 0.0001;  		break;		case 2:		// Rosenbrock			pb.SS.D = 10;			// Boundaries		for (d = 0; d < pb.SS.D; d++)		{				pb.SS.min[d] = -30; pb.SS.max[d] = 30; 
			pb.SS.q.q[d] = 0;
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 	      		}		pb.evalMax =40000; 
		pb.epsilon = 0.0001;			pb.objective = 0;   		break;		case 3:		// Rastrigin			pb.SS.D = 20;		// Boundaries		for (d = 0; d < pb.SS.D; d++)		{			pb.SS.min[d] =-10; 			pb.SS.max[d] =10;   			pb.SS.q.q[d] = 0;	
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 		}		pb.evalMax = 400000; 
		pb.epsilon = 0.0001;			pb.objective = 0;   		break;		case 4:		// Tripod			pb.SS.D = 2;	// 2		// Boundaries		for (d = 0; d < pb.SS.D; d++)		{			pb.SS.min[d] = -100; 			pb.SS.max[d] = 100; 			pb.SS.q.q[d] = 0;	
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 		}		pb.epsilon=0.0001;				pb.evalMax = 10000; 		pb.objective = 0;       		break;		case 5: // Ackley			pb.SS.D = 30;	// Dimension 30		// Boundaries		for (d = 0; d < pb.SS.D; d++)		{			pb.SS.min[d] = -32; 			pb.SS.max[d] = 32; 			pb.SS.q.q[d] = 0;
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 			}		pb.evalMax = 40000; 	
		pb.epsilon=0.0001;
		pb.objective=0;		break;

		case 7: // Pressure vessel
			// Solution: (1.125, 0.625, 58.2901, 43.6927) => 7197.729
			// Solution: (1.125, 0.625, 55.8592, 57.7315) => 7197.729
			pb.SS.D=4;

		pb.SS.min[0] = 1.125; pb.SS.max[0] = 12.5;
		pb.SS.q.q[0] = 0.0625;
		pb.SS.min[1] = 0.625; pb.SS.max[1] = 12.5; 
		pb.SS.q.q[1] = 0.0625;
		pb.SS.min[2] = 0.00000001; pb.SS.max[2] = 240; 
		pb.SS.q.q[2] = 0;
		pb.SS.min[3] = 0.00000001; pb.SS.max[3] = 240; 
		pb.SS.q.q[3] = 0;

		for (d = 0; d < pb.SS.D; d++)                  		{
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 	
		}
		pb.evalMax = 50000 ; 
		pb.epsilon = 0.00001; //0.0000000001;			pb.objective = 7197.72893; //7197.7289277771;
		break;

		case 8 : // Compression spring 
			pb.SS.D=3;

		pb.SS.min[0] = 1; pb.SS.max[0] = 70; pb.SS.q.q[0] = 1;
		pb.SS.min[1] = 0.6; pb.SS.max[1] = 3; pb.SS.q.q[1] = 0;
		pb.SS.min[2] = 0.207; pb.SS.max[2] = 0.5; pb.SS.q.q[2] = 0.001;


		for (d = 0; d < pb.SS.D; d++)                  		{
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 	
		}
		pb.evalMax = 20000 ; 
		pb.epsilon = 1.e-10;			pb.objective = 2.6254214578; 
		break;

		case 9: // Gear train

			pb.SS.D=4;

		for (d = 0; d < pb.SS.D; d++)                  		{
			pb.SS.min[d]=12;
			pb.SS.max[d]=60;
			pb.SS.q.q[d] = 1;
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 	
		}

		pb.evalMax = 20000 ; 
		pb.epsilon = 1.e-13;			pb.objective =2.7e-12 ; 
		break;

		case 10: // Cellular phone
			pb.SS.D=2*10; //2*10  2*nb_of_stations

		for (d = 0; d < pb.SS.D; d++)                  		{
			pb.SS.min[d]=0;
			pb.SS.max[d]=100;
			pb.SS.q.q[d] = 0;
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 	
		}

		pb.evalMax = 20000 ; 
		pb.epsilon = 1e-9;			pb.objective = 0.005530517;
		break;

		case 12: // Schwefel
			pb.SS.D = 20;			// Boundaries		for (d = 0; d < pb.SS.D; d++)		{			pb.SS.min[d] = -500; 			pb.SS.max[d] = 500; 			pb.SS.q.q[d] = 0;
			pb.SS.maxS[d]=pb.SS.max[d];
			pb.SS.minS[d]=pb.SS.min[d]; 			}		pb.evalMax = 400000; 
		pb.epsilon=0.000;
		pb.objective=0;
		break;
	}	pb.SS.q.size = pb.SS.D;	return pb;}


