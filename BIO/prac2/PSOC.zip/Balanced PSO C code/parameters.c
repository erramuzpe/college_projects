printf("\nWARNING: I am simulating Standard PSO 2007, but with the RNG KISS");
param.clamping =1;
param.init=0;
param.initLink=0;
param.initLinkNbMax=1;

param.initVel=5;
param.opposite=0;
//param.localSearch=0;
param.choose_LEA=0;
param.R=0;
param.rand=0; // Use KISS. Actually, it is not precised in SPSO 2007
param.randOrder=1;
param.select=0;
param.strat=0;

param.S = (int) (10 + 2 * sqrt(pb.SS.D));
if (param.S > SMax) param.S = SMax;	param.K=3; 											param.p=1-pow(1-(double)1/(param.S),param.K);param.w[0] = 1 / (2 * log ((double) 2)); // 0.721
wSize=1;param.c2 = 0.5 + log ((double) 2); // 1.193param.c1=param.c2;