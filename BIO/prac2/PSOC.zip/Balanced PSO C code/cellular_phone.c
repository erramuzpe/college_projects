case 10: // Cellular phone
				// Grid 100 x 100. You may modify it for more or less precision
				// (which implies, of course, more or less computation time)
		grid=100;
		f=0;

		dx1=(pb.SS.max[0]-pb.SS.min[0])/grid;

		for(i=0;i<=grid;i++)
		{
			y1=pb.SS.min[0]+i*dx1;
			dx2=(pb.SS.max[1]-pb.SS.min[1])/grid;	
	
			for(j=0;j<=grid;j++)
			{
				y2=pb.SS.min[1]+j*dx2;			
				z=0; // Max field
					for (d = 0; d < xs.size; d=d+2) // For each station
					{
						x1=xs.x[d];
						x2=xs.x[d +1];
	
						z2=1./((x1-i)*(x1-y1) +(x2-j)*(x2-y2)+1);
						if(z2>z) z=z2;
					}
					f=f+z;
			}
		}		f=1./f; // In order to have something to minimise		break;
