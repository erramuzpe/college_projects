Steady State Genetic Algorithm using Real Evolutionary Algorithm Library (Realea library)
--------------------------------------------------------------

This is an implementation of standard real-coded Steady State Genetic Algorithm (SSGA) in C++ implemented by Daniel Molina Cabrera 
daniel.molina@uca.es  for its own use and it is released as free software (license GPL) for being used by other researchers in Soft Computing. 

SSGA is a well-known algorithm that gives very good results in many real problems. It was initially proposed by 
Whitley D. and Kauth in:

Whitley, D. and Kauth, J. (1988). Genitor: A different genetic algorithm. Proceedings of
the Rocky Mountain Conference on Artificial Intelligence, pp. 118–130.

This steady-state Genetic Algorithm is characterized by:In each generation only one or two 
usually only or two offspring are produced. Parents are selected to produce offspring and then a decision 
is made to select which individuals in the population will be deleted in 
order to make room to new offspring. Steady-state GAs are overlapping 
systems because parents and offspring compete for survival. A widely used 
replacement strategy is to replace the worst individual only if the new 
individual is better. We will call this strategy the standard replacement
strategy. 

This code allow :

- Apply different selective methods and different replacement strategies. 

*) Implemented Selective Methods:
    - Tournament Selection (TS). 
    - Negative Assortative Matching (NAM), proposed in 

C. Fernandes and A. Rosa. A study of non-random mating and Varying Population Size in Genetic Algorithms 
Using a Royal Road Function. Proc. of the 2001 IEEE Congress on Evolutionary Computation, pages. 60-66, 2001. 
    
*) Implemented Replacement Strategies:
    - Replace Worst (RW) Strategy. 
    - Deterministic Crowing, proposed in

S.W. Mahfoud. Crowding and preselection revised. Parallel Programming Solving from Nature 2, pages 27-36, 1992.

The combination TS and RW are the standard by literature. However, the defaults operators are NAM and RW, because
it has been proven than they give the best results, see following paper (it is in spanish):

D. Molina, F. Herrera, M. Lozano, Técnicas de Diversidad para Algoritmos Meméticos: un estudio experimental. In Proceedings del MAEB'05 (Cuarto congreso español de Metaheurísticas, Algoritmos Evolutivos y Bioinspirados), Granada (Spain), pages 39-46, 2005.

Before using the algorithm you must set the crossover operator, the selective method, and the replacement strategy
(You should set the mutation also, but it is optional). The combination of the example are recommended: 
crossover operator is BLX-0.5, selective method NAM, replacement strategy RW, and the mutation operator BGA to with 
p_mutation=0.0125.

How to get it
-------------

The last stable version are available from the research group of the author: Soft Computing and Intelligent Information Systems
http://sci2s.ugr.es/EAMHCO/ 

This algorithm requires the Realea library of the same author, from the same webpage.

Install guide
-------------

This algorithm requires the Realea library of the same author, from the same webpage.
It is required for install the software:

* gcc/g++. It has been tested with gcc version 4.4.1.

* CMake version 2.4 or upper (it has been tested with version 2.6). 

* Makefile

* Realea (installed). 

CMake is a building software (like Makefile), and it has to be installed in conjuntion with make to compile 
the library. 

Steps:

* Decompress the library:
tar zxvf realea_ssga.tgz

* Create makefiles
cd ssga; cmake .; 

* Compile 
make 

Test Program
------------
There are one program to show the algorithm.

* main_ssga_cec2005, it uses SSGA for solve CEC2005 test suite. Note: it requires the directory input_data
to run.

The syntax is the following:

<prog> <function> <dimension> [<numtimes=25>]

where <prog> is the name of the problem; <function> is the number of function: for 1 to 25, 
and dimension is the dimensionality. The optional parameter set the number of times it is run, the default value is 25.
