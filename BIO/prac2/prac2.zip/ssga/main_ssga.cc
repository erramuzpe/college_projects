/**
 * Copyright 2008, Daniel Molina Cabrera <danimolina@gmail.com>
 * 
 * This file is part of software Realea
 * 
 * Realea is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Realea is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Foobar.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <realea/common/srandom.h>
#include <realea/common/ea.h>
#include <realea/problem/problemcec2005.h>
#include <realea/ea/ssga/ssga.h>
#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <cassert>

using namespace realea;

void usage(char *prog) {
	printf("usage: %s fun dim [maxrun=25]\n", prog);
}


int main(int argc, char **argv) {
	unsigned int dim;
	int fun, maxRun;

	try {
	Random random(new SRandom(123456789));

	if (argc < 3) {
	    usage(argv[0]);
	    exit(0);
	}

	fun = atoi(argv[1]);
	dim = atoi(argv[2]);

	if (argc > 3) {
	   maxRun = atoi(argv[3]);
	}
	else {
	   maxRun = 25;
	}


	if (dim > 1000) {
	    dim = 1000;
	}

	printf("Fun: %d[%d]\n", fun, dim);

	ProblemCEC2005 problem(&random, dim);
	ProblemPtr prob = problem.get(fun);
	SSGA *ssga = new SSGA(&random);
	EA ea(ssga, prob);
	chc->setCross(new CrossBLX(0.5));
	tChromosomeReal sol(dim);
	tFitness fitness;

	for (int num = 1; num <= maxRun; num++) {
	    ea.apply(sol, &fitness);
	    fitness = prob->eval(sol);
	    fprintf(stdout, "%Le\n", fitness);
	}
    } catch (ConfigException *e) {
	cerr <<"Exception : " <<e->what() <<endl;
	delete e;
    } catch (runtime_error *e) {
	cerr <<"Exception : " <<e->what() <<endl;
	delete e;
    } catch (runtime_error &e) {
	cerr <<"Exception : " <<e.what() <<endl;
    } catch (exception &e) {
	cerr <<"Exception : " <<e.what() <<endl;
    }
    catch (string &str) {
	cerr <<"StrException : " <<str <<endl;
    }

    return 0;
}

//#include "chc.cc"
//int main(int argc, char **argv) {
//	string crossover_str, popsize_str, functions_str, function_str;
//
//        crossover_str = "blx";
//        popsize_str = "50";
//        functions_str = "cec2005";
//        function_str = "1";
//	
//	getConfigUser().realParam(string(crossover_str), string(popsize_str), 
//		  string(functions_str), string(function_str));
//
//	double *sol;
//        int dim;
//        double fit;
//
//	chc(&sol, &dim, &fit);
//	printf("Fitness alcanzado en %s::%s = %lf\n", functions_str.c_str(), function_str.c_str(), fit);
//	return 0;
//}
