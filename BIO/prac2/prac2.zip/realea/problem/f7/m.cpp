#include <iostream>

double fastfractal_doubledip( int dim , double* x );

int main(int argc, char *argv[])
{
	int dim=1000;
	double x[1000];
	for (int i = 0; i < dim; i++)
		x[i]=0.12323;

	double f = 5;
	f=fastfractal_doubledip( dim , x );
	std::cout << "f@0=" << f << std::endl;
	f=fastfractal_doubledip( dim , x );
	x[1]=0.3;
	std::cout << "f@0=" << f << std::endl;
	f=fastfractal_doubledip( dim , x );
	std::cout << "f@0=" << f << std::endl;
	f=fastfractal_doubledip( dim , x );
	std::cout << "f@0=" << f << std::endl;
	x[1]=0.5;
	f=fastfractal_doubledip( dim , x );
	std::cout << "f@0=" << f << std::endl;
	f=fastfractal_doubledip( dim , x );
	std::cout << "f@0=" << f << std::endl;

	return 0;
}

