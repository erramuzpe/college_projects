
#ifndef M_PI
#define M_PI           3.14159265358979323846
#endif

/*Global declarations */
int DIM;
int trialid;
double * peaks;
double * Xopt;
double Fopt;
unsigned int isInitDone;
