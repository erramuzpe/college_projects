
TwoDoubles f1(double* x);
TwoDoubles f2(double* x);
TwoDoubles f3(double* x);
TwoDoubles f4(double* x);
TwoDoubles f5(double* x);
TwoDoubles f6(double* x);
TwoDoubles f7(double* x);
TwoDoubles f8(double* x);
TwoDoubles f9(double* x);
TwoDoubles f10(double* x);
TwoDoubles f11(double* x);
TwoDoubles f12(double* x);
TwoDoubles f13(double* x);
TwoDoubles f14(double* x);
TwoDoubles f15(double* x);
TwoDoubles f16(double* x);
TwoDoubles f17(double* x);
TwoDoubles f18(double* x);
TwoDoubles f19(double* x);
TwoDoubles f20(double* x);
TwoDoubles f21(double* x);
TwoDoubles f22(double* x);
TwoDoubles f23(double* x);
TwoDoubles f24(double* x);

void initbenchmarks();
void finibenchmarks();

bbobFunction handles[24];
unsigned int handlesLength;
