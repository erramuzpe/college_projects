/*
 * Auxiliar.java
 *
 * Created on 15 de marzo de 2008, 11:33
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.vmo.utils;
import java.util.ArrayList;

import org.vmo.core.Node;
import org.vmo.core.*;

/**
 *
 * @author Amilkar Yudier Puris Caceres
 */
public class Auxiliar {
    
    /**Calcula un valor de peso (w) utilizado en el modelo para desplazar algunas soluciones.*/
    public static double weigh( double w0,double wf, int c, int C  ) {
        double w = (( w0 - wf ) * ( C - c )  /( C )+ wf );
        return w;
    }
    /**Calcula la distancia maxima permitida entre cada nodo de la malla*/
    public static double distanceShare_Calculate(double min, double max, int currentCycle, int totalCycle){
        if (currentCycle < totalCycle/4){
            return (Math.abs(min)+Math.abs(max))/4;
        }
        else if((currentCycle >= totalCycle/4) && (currentCycle < totalCycle/2 )){
            return (Math.abs(min)+Math.abs(max))/8;
        }
        else if((currentCycle >= totalCycle/2) && (currentCycle < 2*totalCycle/3 )){
            return (Math.abs(min)+Math.abs(max))/16;
        }
        else if((currentCycle >= 2*totalCycle/3) && (currentCycle < 3*totalCycle/4)){
            return (Math.abs(min)+Math.abs(max))/50;
        }
        else
            return (Math.abs(min)+Math.abs(max))/100;
       }

    
    /**Calcula la norma entre dos valores*/
    public static double calculate_Norma(double[] v1, double []v2){
    	double suma = 0;
    	for(int i=0; i< v1.length;i++){
    		suma += Math.pow(v1[i]-v2[i], 2);
    	}
    	return Math.sqrt(suma);
    }
    /**Calcula el factor de proporsionalidad r en funcion de dos fitness*/
    public static double calculate_Pr( double fitness_n1, double fitness_n2 ) {
        return 1/(1+(fitness_n1-fitness_n2));
    }
       /**Calcula la amplitud media entre los dos valores que
     * limitan el intervalo de busqueda de la solucion.*/
    public static double halfAmplitude_Calculate( double value1, double value2 ) {
        return ( Math.abs( value1 ) + Math.abs( value2 ) ) / 2;
    }
    
    /**Calcula el punto medio entre dos valores*/
    public static double halfPoint_Calculate( double value1, double value2 ) {
        return ( value1 + value2 ) / 2;
    }
    /**Calcula el valor medio entre 4 valores.*/
     public static double halfPoint_Calculate( double value1, double value2, double value3, double value4 ) {
        return ( value1 + value2 + value3 + value4 ) / 2;
    }

     /**Calcula el centro entre 4 valores*/
    public static double centerPoint_Calculate( double valueActual, double bestValue, double value1, double value2 ) {
        return ( valueActual + bestValue + value1 + value2 ) / 4 + bestValue;
    }
    /**Calcula un numero aleatorio con distribucion normal.*/
    public static double randomValue_Normal(double desv) {
        double u1 = 0;
        double u2 =0;
        double result= 0;
        while(u1==0)
            u1 = Math.random();
        u2 = Math.random();
        result = desv * Math.sqrt(-2*Math.log(u1))* Math.sin(2*Math.PI*u2);
        return result;
    }
    
    /**Calcula un numero aleatorio entre "min" (incluido) y "max" (incluido).*/
    public static double randomValue_Generate(double minValue, double maxValue) {
        return minValue + randomValue_Generate(maxValue - minValue);
    }
    
    /**Calcula un numero aleatorio entre 0 (incluido) y el "max" (incluido).*/
    public static double randomValue_Generate(double maxValue) {
        return Math.random() * maxValue;
    }
    
    /**Crea una matrix simetrica con la distancias de cada Nodo
     *a los otros de la malla.*/
    public static double[][] distanceMatrix_Calculate( ArrayList<Node> initialMesh ) {
        double[][] matrix = new double[initialMesh.size()][initialMesh.size()];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = i+1; j < matrix.length; j++) {
                matrix[i][j] = matrix[j][i] = Auxiliar.calculate_EuclidiaDistance(initialMesh.get(i), initialMesh.get(j));
            }
        }
        return matrix;
    }
    
    
    
    /**Ordena los nodos de la malla inicial de manera descendiente teniendo en cuenta el valor
     * de la norma de cada uno.*/
    public static void sortByNorma( ArrayList<Node> mesh ) {
        for ( int i = 0; i < mesh.size(); i++ ) {
            Node temp = mesh.get( i );
            int j = i;
            for ( ; j > 0 && temp.get_NormaValue() < mesh.get( j - 1 ).get_NormaValue(); j-- ) {
            	mesh.set( j, mesh.get( j - 1 ) );
            }
            mesh.set( j, temp );
        }
    }
    
   
    /**Ordena la malla descendentemente teniendo en cuenta  el fitness
     * de cada nodo.*/
    public static void sortByEvaluation( ArrayList<Node> mesh) {
        for ( int i = 0; i < mesh.size()-1; i++ ) {
            
            for (int j = i+1; j < mesh.size(); j++) {
                if(mesh.get(i).get_GoalFunctionEvaluation()> mesh.get(j).get_GoalFunctionEvaluation()){
                    Node temp = mesh.get( i );
                    mesh.set(i, mesh.get(j));
                    mesh.set(j, temp);
                }
            }
                  
        }
    }
    
    /**Ordena los k vecinos mas cercanos de manera descendente en funcion del fitness*/
    public static Node[] sortKnear( Node[] kNeighbour ) {
        
        Node temp[] = new Node[kNeighbour.length];

        
        for (int i = 0; i < temp.length-1; i++) {
            temp[i] = kNeighbour[i];
          for ( int j =i+1 ; j < kNeighbour.length; j++ ) {
            if ( temp[i].get_GoalFunctionEvaluation() > kNeighbour[j].get_GoalFunctionEvaluation() ) {
                temp[i] = kNeighbour[j];
            }
          }
        }
        return temp;
    }
    /**Devuelve el Nodo de mejor fitness (extremo local) de los k vecinos mas cercanos*/
    
    public static Node find_BestLocalNode( Node[] kNeighbour ) {
        Node temp = kNeighbour[ 0 ];
        for ( int i = 1; i < kNeighbour.length; i++ ) {
            if ( temp.get_GoalFunctionEvaluation() < kNeighbour[ i ].get_GoalFunctionEvaluation() ) {
                temp = kNeighbour[ i ];
            }
        }
        return temp;
    }

    public static double centrainPoint(double array[]){
        double result= 0;
        for (int i = 0; i < array.length; i++) {
            result += array[i];
        }
        return result/array.length;
    }
    /**Devuelve el Nodo2var de mejor valor objetivo del arreglo "vector" pasado como parametro.
     * Este metodo se utiliza para obtener el nodo mejor de los k nodos mas cercanos,
     * es decir el posible extremo local, en caso de que sea un problema de maximizacion.*/
    public static Node find_MaxLocalBestNode( Node[] vector ) {
        Node temp = vector[ 0 ];
        for ( int i = 1; i < vector.length; i++ ) {
            if ( temp.get_GoalFunctionEvaluation() < vector[ i ].get_GoalFunctionEvaluation() ) {
                temp = vector[ i ];
            }
        }
        return temp;
    }
    
    
    /** Devuelve el nodo de mejor valor objetivo del ArrayList "vector" pasado como parametro. Este se metodo se utiliza para
     * obtener el global de la malla generada inicialemte. */
    public static Node find_MinGlobalBestNode(ArrayList<Node> vector) {
        Node temp = vector.get(0);
        for (int i = 1; i < vector.size(); i++) {
            if (temp.get_GoalFunctionEvaluation() > vector.get(i).get_GoalFunctionEvaluation()) {
                temp = vector.get(i);
            }
        }
        return temp;
    }
    
    /** Devuelve el nodo de mejor valor objetivo del ArrayList "vector" pasado como parametro. Este se metodo se utiliza para
     * obtener el global de la malla generada inicialemte. */
    public static Node find_MaxGlobalBestNode(ArrayList<Node> vector) {
        Node temp = vector.get(0);
        for (int i = 1; i < vector.size(); i++) {
            if (temp.get_GoalFunctionEvaluation() < vector.get(i).get_GoalFunctionEvaluation()) {
                temp = vector.get(i);
            }
        }
        return temp;
    }
    /// Metodos para el trabajo con los optimos locales en Modified VMO. 
    /**Busca los k optimos locales de la malla inicial de cada paso o iteracion */
    //////////////////////////////////////////////////////////////
    //selcciona los k primeros nodos de la malla inicial
    public static ArrayList<Node> k_LocalBest(int k, ArrayList<Node> inicialMesh){
       
        ArrayList<Node> result= new ArrayList<Node>();
        for (int i = 0; i < k; i++) {
            result.add(inicialMesh.get(i));
            
        }
        return result;
    }
     // selecciona de los vecinos mas cercanos el extremo local con mejor fitness
    public static Node selectOf_kLocalOptimum(Node current, ArrayList<Node> klocalNodes){
        int index = 0;
        double euclidian_distance = calculate_EuclidiaDistance(current, klocalNodes.get(0));
    	for (int i = 1; i < klocalNodes.size(); i++) {
            double tempDistance = calculate_EuclidiaDistance(current, klocalNodes.get(i));
            if (euclidian_distance > tempDistance){
            	index =i;
            	euclidian_distance=tempDistance;
            }
        }
        return klocalNodes.get(index);
    }
         // selecciona de los vecinos mas cercanos el extremo local por el metodo de la ruleta
    public static Node selectOf_kLocalOptimum_Ruleta(ArrayList<Node> kLocalOptimum) {
    	 double minimo = 0;
 		double maximo = 0;
 		int numAux = 0;
         double sum= 0;
         double arrayPj[] = new double[kLocalOptimum.size()];
         for (int i = 0; i < arrayPj.length; i++) {
             sum += arrayPj[i]=kLocalOptimum.get(i).get_GoalFunctionEvaluation();
         }
 		double q= (double)Math.random();
 		//double arrayAux[] = new double[arrayPj.length];
 		for (int i =0; i < arrayPj.length; i++ ){
 			maximo += arrayPj[i]/sum;
 			if (( maximo>= q)&& (q > minimo)) {
 				numAux = i;
 				break;
 			}
 			minimo = maximo;
 		}
 	return kLocalOptimum.get(numAux);
	}
    //selecciona de los vecinos más cercanos el extremo local de manera aleatoria
    public static Node selectOf_kLocalOptimum_Randome(ArrayList<Node> kLocalOptimum) {
   	 
    	double number = Math.random()*kLocalOptimum.size()-1;
    	return kLocalOptimum.get((int)Math.ceil(number));
	}
    
    
    ///////////////////////////////////////////////////////

    /**Busca los k vecinos mas cercanos a un nodo especificado
     * con el indice i.*/
    public static Node[] find_NearKNodos(ArrayList<Node> inicialMesh, int kNear, int i, double[] rowNeighbors) {
        int index = 0;
        Node[] nears = new Node[kNear];
        double[] aux = rowNeighbors.clone();
        double menor = aux[i] = Double.MAX_VALUE;
        int k = 0;
        while (k < kNear) {
            for (int j = 0; j < aux.length; j++) {
                if (aux[j] < menor) {
                    menor = aux[j];
                    index = j;
                }
            }
            nears[k] = inicialMesh.get(index);
            aux[index] = Double.MAX_VALUE;
            menor = aux[index];
            k++;
        }
        return nears;
    }
   
    //elimina de la malla los nodos que no cumple con una cota de distancias.
    public static void deleteDuplicate(ArrayList<Node> totalMesh, double shareDistance) {
        for (int i = 0; i < totalMesh.size(); i++) {
            for (int j = i + 1; j < totalMesh.size(); j++) {
                if ( Math.abs( Auxiliar.calculate_EuclidiaDistance(totalMesh.get(i), totalMesh.get(j)) ) < shareDistance  && i != j) {
                    totalMesh.remove(j);
                }
            }
        }
    }
    // retorna el nodo más cercano de otro nodo de la malla
    public static Node find_NearNode(ArrayList<Node> malla, Node temp){
        int indice = 0;
        for (int i = 1; i < malla.size(); i++) {
            if(Auxiliar.calculate_EuclidiaDistance(malla.get(indice), temp) > Auxiliar.calculate_EuclidiaDistance(malla.get(i), temp)){
                indice = i;
            }
        }
        return malla.get(indice);
    }
  ///////////////////////////////////////
  // Calculo de las distancias //

    /**Calcula la distancia entre dos nodos según la función coseno.*/
    public static double calculate_CosenoDistance( Node n1, Node n2 ) {
        double aux1[] = n1.get_ValuesArray();
        double aux2[] = n2.get_ValuesArray();
        double sum = 0;
        for (int i = 0; i < aux1.length; i++) {
            sum += aux1[i]*aux2[i];

        }
        return 1- sum/ (n1.get_NormaValue()*n2.get_NormaValue());

    }

    /**Calcula la distancia entre dos nodos según la ecuación de Euclides.*/
    public static double calculate_EuclidiaDistance( Node n1, Node n2  ) {
          double aux1[] = n1.get_ValuesArray();
          double aux2[] = n2.get_ValuesArray();
          double sum = 0;
          for (int i = 0; i < aux1.length; i++) {
               sum += Math.pow(aux1[i] - aux2[i],2);
        }

        return Math.sqrt( sum );
    }
      
}


