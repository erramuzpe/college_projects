/*
 *
 *
 * Created on 15 de marzo de 2008, 11:46
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.vmo.core;

import org.vmo.functions.test_func;
import org.vmo.utils.Auxiliar;

/**
 *
 * @author Amilkar Yudier Puris Caceres
 */
public class Node {
    
    //atributos
    private double [] values;
    private double goalFuntionValue;
    private double normaValue;
    private int marca;     //este atributo es para identificar con cual funcion de generacion fue creado el nodo.
        
    
    public Node(double minValue, double maxValue, test_func testF)
    {
        this.values = new double[testF.dimension()];
        for (int i = 0; i < this.values.length; i++) {
             this.values[i]= Auxiliar.randomValue_Generate(minValue, maxValue);

        }
        this.goalFuntionValue = testF.f(this.values)- testF.bias();
    }

    public Node(double[] n, test_func testF, int marca) {
        this.values = n.clone();
        this.goalFuntionValue = testF.f(this.values)- testF.bias();
        this.normaValue  = this.norma();
        this.marca = marca;
    }
         
    private double norma() {
        double sum = 0;
        for (int i = 0; i < values.length; i++) {
            sum += Math.sqrt( Math.pow( values[i], 2 ));
        }
        return sum;
        
    }
        /**Genera un nodo aleatoriamente, con componentes dentro del
     * dominio de solucion.*/
    public static Node randomeNode_Generate( double minValue, double maxValue,test_func testF ) {
        double aux[] = new double[testF.dimension()];
        for (int i = 0; i < aux.length; i++) {
             aux[i]= Auxiliar.randomValue_Generate(minValue, maxValue);

        }
        return new Node(aux, testF, 0);
    }
     
       
        
    /**Devuelve el contenido de un Nodo como una cadena de caracteres.*/
    public String toString() {
        String cad = "";
        for (int i = 0; i < values.length; i++) {
             cad +="X" + i +" = "+ Double.toString(values[i])+" ";
        }
        return cad;//.concat("Evaluation = "+ this.evaluation());
        
     }
    
    /**Devuelve el contenido de la componente x como una cadena de caracteres.*/
   

    public double[] get_ValuesArray() {
        return values;
    }

    public void set_ValuesArray(double[] n) {
        for (int i = 0; i < n.length; i++) {
            this.values[i]= n[i];
        }
    }
    
    public double  get_GoalFunctionEvaluation(){
        return   this.goalFuntionValue;
    }
    public void set_GoalFunctionEvaluation(double value){
        this.goalFuntionValue = value;
    }
    public double get_NormaValue(){
        return this.normaValue;
    }
    public void set_NormaValue(double value){
        this.normaValue = value;
    }
    public int get_Marca(){
        return this.marca;
    }
    public void set_Marca(int value){
        this.marca= value;
    }
 }
