/*
 * Main.java
 *
 * Created on 15 de marzo de 2008, 11:30
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 *
 *
 *
 */

package org.vmo.core;


import org.vmo.exceptions.ParametersException;
import org.vmo.functions.benchmark;
import org.vmo.functions.test_func;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import org.vmo.functions.test_func;
import org.vmo.utils.Auxiliar;
import org.vmo.utils.desviacionEstandar;



/**
 *
 * @author Amilkar Yudier Puris C�ceres
 */
public class Main {

  private static double [][] allFuncionRange ={{-100,100},{-100,100},{-100,100},{-100,100},{-100,100},{-100,100},{0,600},{-32,32},{-5,5},{-5,5},{-0.5,0.5},{-3.14,3.14},{-5,5},{-100,100},{-5,5},{-5,5},{-5,5},{-5,5},{-5,5},{-5,5},{-5,5},{-5,5},{-5,5},{-5,5},{2,5}};

  /*
 * Esta funcion recibe una cadena de caracteres la cual contiene una expresion de las funciones que se quieren minimizar.
 * Los operadores especiales para minimizar mas de una funcion son "," y el "-". el primer operador define las funciones a cargar Ejemplo "f6,f12,f17,f25"
 * y el otro operador define intervalo de funciones. Ejemplo f6-f12, donde minimiza la funciones desde la f6 hasta la f12. si se quiere ejecutar todas las funciones se puede
   * poner la palabra "All". tambien se puede mesclar ambos operadores.Ejemplo "f6,f8-f12,f20-f25".
 */

	private static ArrayList<Integer> funtionTestsToExecute(String args){
		ArrayList<Integer> result=new ArrayList<Integer>();
		if(args.compareToIgnoreCase("All")==0){
			for (int i = 0; i < 20; i++) {
				result.add(i+6);
			}
            return result;
		}
		else if(!args.contains(",")&& !args.contains("-")){
            String cad =  args.substring(1);
            result.add(Integer.parseInt(cad));
            return result;
        }
        else{
           
           String cad1="";
           String cad2="";

           for(int i=0; i< args.length(); i++){
               if (args.charAt(i)==',' || args.charAt(i)=='-'){
                   int k=i-1;
                   int j=i+2;
                   
                   while(Character.isDigit(args.charAt(k)))
                       cad1=args.charAt(k--)+ cad1;
                    
                   while(j<args.length() && Character.isDigit(args.charAt(j)))
                       cad2+=args.charAt(j++);
                  // 
                   if(args.charAt(i)==','){
                       if(result.contains(Integer.parseInt(cad1)))
                         result.add(Integer.parseInt(cad2));
                       else{
                           result.add(Integer.parseInt(cad1));
                           result.add(Integer.parseInt(cad2));
                       }
                   }
                   else{
                       int s=Integer.parseInt(cad1);
                       if(result.contains(s))
                           s++;

                       for(;s<=Integer.parseInt(cad2);s++)
                           result.add(s);
                        
                   }
                   i=j-1;
                   cad1="";
                   cad2="";

               }
              
           }
           return result;
        }
    }

   /*
 * Esta funcion recibe una cadena de caracteres la cual define las dimensiones que se utilizaran. Ejemplo "All" significa todas las dimenciones.
    * en el caso de que se quiera experimentar con una en particular se pone "D10" o"D30" o "D50"
 */
    private static int[]setDimencion (String cad){
       int [] dimension;
        if(cad.compareToIgnoreCase("AllDimension")==0){
           dimension = new int[3];
           dimension[0]=10;
           dimension[1]=30;
           dimension[2]=50;
       }
        else if(cad.compareToIgnoreCase("D10")==0){
            dimension =new int[1];
            dimension[0]=10;
        }
        else if(cad.compareToIgnoreCase("D30")==0){
            dimension =new int[1];
            dimension[0]=30;
        }
        else{
            dimension =new int[1];
            dimension[0]=50;
        }
     return dimension;

    }

    /*
 * Este es el main de VMO y en el se configuran de manera manual los parametros utilizados por el modelo. estos son
     * funtionTest = funcion o funciones a minimizar, neighbour = cantidad de vecinos mas cercanos, dimension = la o las dimensiones utilizadas
     * el tamanno inicial y final de la malla (12, 36). Solo se hacen 10 ejecuciones independiente y los resultados mostrados son:
     * el mejor, el peor, el promedio y la septima solucion.
     *
 */

  	public static void main(String[] args) {
      //ArrayList<Integer> funtionTest = Main.funtionTestsToExecute(args[0]);
  	  ArrayList<Integer> funtionTest = Main.funtionTestsToExecute("f6");
      //int neighbour = Integer.valueOf(args[2]);
       int neighbour = 3;
       //int dimension[]= Main.setDimencion(args[1]);
  	   int dimension[]= Main.setDimencion("d10");
       for(int k = 0; k<dimension.length; k++){
          benchmark b = new benchmark();
          System.out.println("Results of the Dimension "+ dimension[k]);
          System.out.println("----------------------------");
          for(int p =0; p< funtionTest.size(); p++){
               test_func  testF =b.testFunctionFactory(funtionTest.get(p),dimension[k]);
               double averageVMO = 0;
               double bestSolution = Double.MAX_VALUE;
               double worseSolution = Double.MIN_VALUE;
               double solutionOfVMO[] = new double[25];
               System.out.println("Results of the function F"+ funtionTest.get(p));
               
               for (int i = 0; i <10; i++) {
                     try {
                       VariableMesh vmo = new VariableMesh( 12,36,dimension[k]*10000, neighbour, Main.allFuncionRange[funtionTest.get(p)-1][0], Main.allFuncionRange[funtionTest.get(p)-1][1],testF);
                       vmo.run_VMOAlgorithm();
                       averageVMO += solutionOfVMO[i] = vmo.getBestNode().get_GoalFunctionEvaluation();
                       bestSolution = (bestSolution  > solutionOfVMO[i] ? solutionOfVMO[i] : bestSolution);
                       worseSolution = (worseSolution  > solutionOfVMO[i] ? worseSolution : solutionOfVMO[i]);

                     }
                     catch(ParametersException ex) {
                           ex.printStackTrace();
                     }

               }
              System.out.println("Best: "+bestSolution);
              System.out.println("Worse: "+worseSolution);
              System.out.println("Average: "+ averageVMO/10);
              System.out.println("Seven Solution: "+solutionOfVMO[6]);
              System.out.println("");
          }
       }
  	}
}
 


