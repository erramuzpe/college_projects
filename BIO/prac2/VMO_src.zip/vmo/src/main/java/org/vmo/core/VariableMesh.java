/*
 * VariableMesh.java
 *
 * Created on 29 de marzo de 2008, 15:11
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.vmo.core;
import org.vmo.exceptions.*;
import org.vmo.functions.benchmark;
import org.vmo.functions.test_func;
import java.util.*;
import org.vmo.utils.Auxiliar;
import org.vmo.utils.Expansion_Process;

/**
 *
 * @author Amilkar Yudier Puris C�ceres
 */
public class VariableMesh {
    
    //atributos
    private ArrayList<Node> totalMesh;
    private ArrayList<Node> inicialMesh;
    private int size_inicialMesh;
    private int size_totalMesh;
    private int evaluationNumber;
    private int k_neighbourhood;
    private double lowest;
    private double supreme;
    private Node bestNode;
    private double w0;
    private double wf;
    private test_func testF;
       
    
    /** crea una instancia con los atributos siguientes
     * n-- tamano de la malla inicila
     * m--tamano de la malla total
     * evaluationNumber--total de evaluaciones de la funcion objetivo
     * k-- cantidad de vecinos mas cercanos 
     * inf y sup---dominio de la funcion
     * testF--objeto para el trabajo con las funcion del cec2005
     *  */
    public VariableMesh( int n, int m, int evaluationNumber, int k, double inf, double sup, test_func testF  ) throws ParametersException {
        this.size_inicialMesh = n;
        this.size_totalMesh = m;
        this.evaluationNumber = evaluationNumber;
        this.k_neighbourhood = k;
        this.lowest = inf;
        this.supreme = sup;
        this.testF = testF;
        this.inicialize_InicialMesh();
        this.inicialize_TotalMesh();
        this.bestNode = Auxiliar.find_MinGlobalBestNode(this.inicialMesh);
        this.w0 = (Math.abs(this.lowest) + Math.abs(this.supreme))/10;
        this.wf = (Math.abs(this.lowest) + Math.abs(this.supreme))/100;
        
    }
   /** Inicializa la malla total con lo nodos de la malla inicial */
     public void inicialize_TotalMesh(){
        this.totalMesh = new ArrayList<Node>();
        for (int i = 0; i < size_inicialMesh; i++) {
            totalMesh.add(inicialMesh.get(i));
        }
    }
     public double averege_Distance(double distance_Matrix[][]){
         double suma = 0;
         for (int i = 0; i < distance_Matrix.length; i++) {
             suma += distance_Matrix[0][i];

         }
         return suma/ distance_Matrix.length;
     }
 /** Crea de manera aleatoria la malla inicial de la primera iteracion*/
     public void inicialize_InicialMesh(){
        this.inicialMesh = new ArrayList<Node>();
        for (int i = 0; i < this.size_inicialMesh; i++) {
            this.inicialMesh.add(new Node(this.lowest, this.supreme,this.testF));
            
        }
    }
     
      

    /*Metodo de optimizacion para caso de minimizacion. */
    public void run_VMOAlgorithm() {
        double[][] distance_Matrix = new double[this.size_inicialMesh][this.size_inicialMesh];
        int currentEvaluation = this.size_inicialMesh;
        Node temp = null;
        int createdNodes = this.size_inicialMesh ;

        while( currentEvaluation < this.evaluationNumber ) {
             /* paso I: Generar nodos a partir de cada nodo de la malla inicial
            con respecto a su extremo local en caso de tener. */
            double distanceShare = Auxiliar.distanceShare_Calculate(this.lowest, this.supreme, currentEvaluation, this.evaluationNumber );
            distance_Matrix = Auxiliar.distanceMatrix_Calculate(this.inicialMesh).clone();
            
            for (int i = 0; i < this.size_inicialMesh; i++) {
                Node ni = this.inicialMesh.get(i);
                Node [] k_Near = Auxiliar.find_NearKNodos(this.inicialMesh, this.k_neighbourhood, i, distance_Matrix[i]);
                Node nl = Auxiliar.find_BestLocalNode(k_Near);
                if (nl.get_GoalFunctionEvaluation()< ni.get_GoalFunctionEvaluation()) {
                	double [] nf_values = Expansion_Process.vmo_F_Funtion(ni.get_ValuesArray(), nl.get_ValuesArray(), distanceShare, Auxiliar.calculate_Pr(ni.get_GoalFunctionEvaluation(), nl.get_GoalFunctionEvaluation()));
                	//double [] nf_values = Expansion_Process.corssover_BLX_Alpha(0.5, ni.get_ValuesArray(), nl.get_ValuesArray());
                	//double [] nf_values = Expansion_Process.crossover_BLX_AlphaBeta(1-,Auxiliar.calculate_Pr(ni.get_GoalFunctionEvaluation(), nl.get_GoalFunctionEvaluation()),ni.get_ValuesArray(), nl.get_ValuesArray());
                	//double [] nf_values = Expansion_Process.crossover_Arithmetical(1/2, ni.get_ValuesArray(), nl.get_ValuesArray());
                	//double [] nf_values = Expansion_Process.crossover_Geometrical(1/2, ni.get_ValuesArray(), nl.get_ValuesArray());
                	//double [] nf_values = Expansion_Process.crossover_PBX_Alpha(0.8,this.infimo,this.supremo, ni.get_ValuesArray(), nl.get_ValuesArray());
                	//double [] nf_values = Expansion_Process.crossover_PBX_Alpha(1-Auxiliar.calculate_Pr(ni.get_GoalFunctionEvaluation(), nl.get_GoalFunctionEvaluation()),this.infimo,this.supremo, ni.get_ValuesArray(), nl.get_ValuesArray());
                	//double [] nf_values = Expansion_Process.crossover_Wright_Heuristic(ni.get_ValuesArray(), nl.get_ValuesArray());
                	//double [] nf_values = Expansion_Process.crossover_Linear_BGA(this.infimo, this.supremo, ni.get_ValuesArray(), nl.get_ValuesArray());
                	this.totalMesh.add(new Node(this.chekingOfSolution(nf_values), this.testF, 1));
                    currentEvaluation++;
                    
                }
            }
            
            /* paso II: Generar nodos a partir de cada nodo de la malla inicial
            respecto solamanete al extremo global. */
           for (int i = 0; i < this.size_inicialMesh; i++) {
                Node ni = this.inicialMesh.get(i);
                //double [] nf_values = Expansion_Process.corssover_BLX_Alpha(0.5, ni.get_ValuesArray(), this.global.get_ValuesArray());
                //double [] nf_values = Expansion_Process.crossover_PBX_Alpha(0.3,this.infimo,this.supremo, ni.get_ValuesArray(), global.get_ValuesArray());
                //double [] nf_values = Expansion_Process.crossover_Wright_Heuristic(ni.get_ValuesArray(), global.get_ValuesArray());
            	//double [] nf_values = Expansion_Process.crossover_Linear_BGA(this.infimo, this.supremo, ni.get_ValuesArray(), global.get_ValuesArray());
                double [] nf_values = Expansion_Process.vmo_G_Funtion(ni.get_ValuesArray(), this.bestNode.get_ValuesArray(), Auxiliar.calculate_Pr(ni.get_GoalFunctionEvaluation(), this.bestNode.get_GoalFunctionEvaluation()));
                //double [] nf_values = Expansion_Process.crossover_Arithmetical(1/2, ni.get_ValuesArray(), this.global.get_ValuesArray());
                this.totalMesh.add(new Node(this.chekingOfSolution(nf_values),this.testF,2)); //genero un nuevo nodo y lo adiciono a la mallaTotal
                currentEvaluation++;
                
            }
          
            /* paso III: Generacion de los nodos faltantes a partir de los nodos mas y
            menos externos de la malla inicial. */
            int missingNodes = this.size_totalMesh - (currentEvaluation + this.size_inicialMesh);
            ArrayList<Node> frontiers = Expansion_Process.vmo_H_Funtion(this.inicialMesh, w0,wf, currentEvaluation, this.evaluationNumber, this.lowest, this.supreme, missingNodes, this.testF);
            
            for (int i = 0; i < frontiers.size(); i++) {
                temp = frontiers.get(i);
                this.totalMesh.add(temp);
                currentEvaluation++;
            }
            
            /* paso IV: Contruccion de la nueva malla inicial de la proxima iteracion. */
            Auxiliar.sortByEvaluation(this.totalMesh);
            Auxiliar.deleteDuplicate(this.totalMesh, distanceShare);
            if ( this.totalMesh.size() >= this.size_inicialMesh ) {
                this.initialize_InitiaMeshWithBestsNode();

            } 
            else  {
                for ( int i = 0; i < this.totalMesh.size() - 1; i++ ) {
                    this.inicialMesh.set(i, this.totalMesh.get(i));
                }
                for (int i = 0; i < this.size_inicialMesh - this.totalMesh.size(); i++) {
                    this.inicialMesh.set(this.totalMesh.size()+i ,new Node( this.lowest, this.supreme, this.testF ));
                    currentEvaluation++;
                }
                
            }
             double a = this.totalMesh.get(0).get_GoalFunctionEvaluation();
             double d = this.bestNode.get_GoalFunctionEvaluation();
           if (this.totalMesh.get(0).get_GoalFunctionEvaluation() < this.bestNode.get_GoalFunctionEvaluation()) { //actualizo el nodo global en cada generacion
               this.bestNode = this.totalMesh.get(0);
                      
            }
            this.inicialize_TotalMesh();
         }
       }
    
     /** Inicializa la malla inicial con los nodos de mejor y peor fitness de la malla total */
	public void initialize_InitiaMeshWithBestsWorstNode(){
        int position = Math.round(this.size_inicialMesh/2);
        for (int i = 0; i < position; i++) {
           this.inicialMesh.set(i, this.totalMesh.get(i));
        }
        int k=0;

        for (int i = position; i < this.size_inicialMesh; i++) {
           this.inicialMesh.set(i, this.totalMesh.get(this.totalMesh.size()-1-k++));
        }
    }
  /** Inicializa la malla inicial con los nodos de mejor fitness de la malla total */
    public void initialize_InitiaMeshWithBestsNode(){
        
        for (int i = 0; i < this.size_inicialMesh; i++) {
           this.inicialMesh.set(i, this.totalMesh.get(i));
        }
    }

    public int getSizeInitialMesh() {
        return size_inicialMesh;
    }
    
       
    public int getSizeTotalNodos() {
        return size_totalMesh;
    }
    private double [] chekingOfSolution(double [] values){
    	for (int i = 0; i < values.length; i++) {
			if (values[i] < this.lowest)
			   values[i] =  this.lowest;
			else
				if (values[i]> this.supreme)
					values[i]= this.supreme;
		}
    	return values;
    }
       
    public int getEvaluationNumber() {
        return evaluationNumber;
    }
    
    public void setEvaluationNumber(int e) {
        this.evaluationNumber = e;
    }
     
    public int getKNeighbourhood() {
        return k_neighbourhood;
    }
    
    public void setKNeighbourhood(int k) {
        this.k_neighbourhood = k;
    }
    
    public double getLowest() {
        return lowest;
    }

    public void setLowest(double l) {
        this.lowest = l;
    }
    
    public double getSupreme() {
        return supreme;
    }
    
    public void setSupreme(double s) {
        this.supreme = s;
    }
   
    public Node getBestNode() {
        return this.bestNode;
    }
       
    public void PrintInitialMesh(){
    	for(int i=0; i< this.inicialMesh.size() ; i++){
    		System.out.println("Nodo numero "+i+ " Calidad = "+ this.inicialMesh.get(i).get_GoalFunctionEvaluation());
    	}
    }
    
}
