/*
 * desviacionEstandar.java
 *
 * Created on October 29, 2008, 3:10 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.vmo.utils;
import java.math.MathContext;
import java.util.*;
/**
 *
 * @author puris
 */
public class desviacionEstandar {
    
    /** Creates a new instance of desviacionEstandar */
    public desviacionEstandar() {
    }
    public static double desviacionEstandar_Calculate(double data[], double halfError){
        double sum = 0.0;
        for (int i = 0; i < data.length; i++) {
            sum += Math.abs(data[i]- halfError);

        }
        return sum;
    }
}
