package org.vmo.utils;
import java.util.ArrayList;

import org.vmo.functions.test_func;
import org.vmo.core.Node;
public class Expansion_Process {
     
///// Operadores Gen�ticos utilizando la generaci�n de un solo nodo///////////////	
	
	public static double[] corssover_BLX_Alpha(double alpha, double[] values_n1, double[] values_n2 ){
		double result[] = new double[values_n1.length];
		for (int i = 0; i < values_n1.length; i++) {
           double puntox = values_n1[i];
           double puntoy = values_n2[i];
           double I = Math.abs(puntoy - puntox)*alpha;
           if(puntox> puntoy){
        	   double aux = puntox;
               puntox = puntoy;
               puntoy = aux;
           }
           double A1 = puntox -I;
           double B1 = puntoy +I;
           result[i]= A1 + Math.random() * (B1 - A1);
        }
         
       return result;
 
	}
	
	public static double[] crossover_Wright_Heuristic(double[] values_n1, double[] values_n2){
		double result[] = new double[values_n1.length];
		double u = Math.random();
		for (int i = 0; i < values_n1.length; i++) {
			result[i] = u *(values_n2[i]-values_n1[i])+values_n2[i];
		}
		return result;
	}
	
	private static double calculate_Sita(){
        double result = 0; 
		for (int i = 0; i < 16; i++) {
		    result = Math.random()* Math.pow(2, -i); 	
		 }
		return result;
	}
	public static double[] crossover_Linear_BGA(double a, double b, double[] values_n1, double[] values_n2){
		double result[] = new double[values_n1.length];
		double r =0.5*(b-a);		
		double norma = Auxiliar.calculate_Norma(values_n1, values_n2);
		for (int i = 0; i < values_n1.length; i++) {
			double sign = 1;
			if (Math.random()>0.9){
				sign= -1;
			}
			result[i]= values_n2[i]+ (sign * calculate_Sita()*(values_n1[i]-values_n2[i])/norma); 
		}
		
		return result;
	}
	
	public static double[]crossover_BLX_AlphaBeta(double alpha,double beta, double[] values_n1, double[] values_n2){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
           double puntox = values_n1[i];
           double puntoy = values_n2[i];
           double I = Math.abs(puntoy - puntox);
           if(puntox> puntoy){
        	   double aux = puntox;
               puntox = puntoy;
               puntoy = aux;
           }
           double A1 = puntox -I*alpha;
           double B1 = puntoy +I*alpha;
           result[i]= A1 + Math.random() * (B1 - A1);
        }
         
       return result;
	}
	// este operador gen�tico obtiene soluciones cercanas al segundo nodo n2 con alpha [0.5, 1] 
	public static double[]crossover_PBX_Alpha(double alpha,double inf, double sup, double[] values_n1, double[] values_n2){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
           
           double puntox = values_n1[i];
           double puntoy = values_n2[i];
           double I = Math.abs(puntoy - puntox);
           double l= Math.max(inf, puntoy-I*alpha);
           double u= Math.max(inf, puntoy+I*alpha);
           
           result[i]= l + Math.random() * (u - l);
        }
         
       return result;
	}
	
	public static double[]crossover_Arithmetical(double lambda, double[] values_n1, double[] values_n2){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
           result[i]= lambda*values_n1[i] + (1-lambda)*values_n2[i];
        }
         
       return result;
	}
	
	public static double[]crossover_Geometrical(double omega, double[] values_n1, double[] values_n2){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
           result[i]= Math.pow(values_n1[i], omega)* Math.pow(values_n2[i], 1-omega);
        }
         
       return result;
	}
	//////////////////////////////////////////////////////////////////////////
	/////Operadores Gen�tiocos que generan un solo nodo combinando la generacion de dos hijos/// 
	
	public static double[] corssover_BLX_Alpha(double alpha, double[] values_n1, double[] values_n2, double r ){
		double result[] = new double[values_n1.length];
		for (int i = 0; i < values_n1.length; i++) {
           double puntox = values_n1[i];
           double puntoy = values_n2[i];
           double I = Math.abs(puntoy - puntox)*alpha;
           if(puntox> puntoy){
               puntox = puntoy;
           }
           double A1 = puntox -I;
           double B1 = puntoy +I;
           result[i]= A1 + Math.random() * (B1 - A1);
        }
         
       return result;
 
	}
	
	public static double[] crossover_Wright_Heuristic(double[] values_n1, double[] values_n2, double r){
		double result[] = new double[values_n1.length];
		double u = Math.random();
		for (int i = 0; i < values_n1.length; i++) {
			result[i] = u *(values_n2[i]- values_n1[i])+values_n2[i];
		}
		return result;
	}
	
	
	public static double[] crossover_Linear_BGA(double a, double b, double[] values_n1, double[] values_n2, double r){
		double result[] = new double[values_n1.length];
		double ro =0.5*(b-a);		
		double norma = Auxiliar.calculate_Norma(values_n1, values_n2);
		for (int i = 0; i < values_n1.length; i++) {
			double sign = 1;
			if (Math.random()>0.9){
				sign= -1;
			}
			result[i]= values_n2[i]+ sign*(ro * calculate_Sita()*(values_n1[i]-values_n2[i])/norma); 
		}
		
		return result;
	}
	
	public static double[]crossover_BLX_AlphaBeta(double alpha,double beta, double[] values_n1, double[] values_n2, double r){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
           double puntox = values_n1[i];
           double puntoy = values_n2[i];
           double I = Math.abs(puntoy - puntox);
           if(puntox> puntoy){
               puntox = puntoy;
           }
           double A1 = puntox -I;
           A1*=alpha;
           double B1 = puntoy +I;
           B1*=beta;
           result[i]= A1 + Math.random() * (B1 - A1);
        }
         
       return result;
	}
	// este operador gen�tico obtiene soluciones cercanas al segundo nodo n2 con alpha [0.5, 1] 
	public static double[]crossover_PBX_Alpha(double alpha,double inf, double sup, double[] values_n1, double[] values_n2, double r){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
           
           double puntox = values_n1[i];
           double puntoy = values_n2[i];
           double I = Math.abs(puntoy - puntox);
           double l= Math.max(inf, puntoy-I*alpha);
           double u= Math.max(inf, puntoy+I*alpha);
           
           result[i]= l + Math.random() * (u - l);
        }
         
       return result;
	}
	
	public static double[]crossover_Arithmetical(double lambda, double[] values_n1, double[] values_n2, double r){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
            double randome= Math.random();
            if (randome < r)
        	    result[i]= lambda*values_n1[i] + (1-lambda)*values_n2[i];
            else
            	result[i]= lambda*values_n2[i] + (1-lambda)*values_n1[i];
        }
         
       return result;
	}
	
	public static double[]crossover_Geometrical(double omega, double[] values_n1, double[] values_n2, double r){
		double result[] = new double[values_n1.length];
        for (int i = 0; i < values_n1.length; i++) {
        	double randome = Math.random();
        	if (randome < r)
        		result[i]= Math.pow(values_n1[i], omega)* Math.pow(values_n2[i], 1-omega);
            else
            	result[i]= Math.pow(values_n2[i], omega)* Math.pow(values_n1[i], 1-omega);
            
        }
         
       return result;
	}
	
	////// Funciones de expansion propias de VMO////////////////////////////
	
	public static double[] vmo_F_Funtion(double[] values_ni, double[] values_nl, double distanceShare, double Pr ) {
        double result[] = new double[values_ni.length];
        for (int i = 0; i < result.length; i++) {
            double halfValue = Auxiliar.halfPoint_Calculate(values_ni[i], values_nl[i]);
            if ((Math.random() <= Pr) && (Math.abs(halfValue - values_nl[i]) > distanceShare)){
                 result[i] = halfValue;//+Auxiliar.randomValue_Generate(-1, 1)*0.5*Math.abs(auxN[i]-auxNe[i]);
            }
            else if (Math.abs(halfValue - values_nl[i]) <= distanceShare){
            	double aux = Auxiliar.randomValue_Generate(-distanceShare, distanceShare);
            	result[i] = values_nl[i]+aux;
            }
            else
            	result[i]=Auxiliar.randomValue_Generate( halfValue, values_nl[i]);
         }
          return result;
    }
	
	public static double[] vmo_G_Funtion(double[] values_n, double[] values_ng, double Pr ) {
		double result[] = new double[values_n.length];
        for (int i = 0; i < result.length; i++) {
        	double halfValue = Auxiliar.halfPoint_Calculate(values_n[i], values_ng[i]);
             if (Math.random() < Pr){
                 result[i]= halfValue ;/// Auxiliar.weigh(w0, j, M);
             }
             else{
                 result[i]= Auxiliar.randomValue_Generate(halfValue, values_ng[i]);
             }
        }       
    return result;
	}
	
	public static ArrayList<Node> vmo_H_Funtion(ArrayList<Node> initialMesh, double w0, double wf, int c, int C, double inf, double sup, int quantity, test_func testF) {
		ArrayList<Node> auxiliarMesh = (ArrayList<Node>)initialMesh.clone();
		ArrayList<Node> arrayAuxNode = new ArrayList<Node>();
        Auxiliar.sortByNorma(auxiliarMesh);
        int i;

        
             for ( i = 0; (i < (auxiliarMesh.size())&& i<(quantity / 2)); i++) {
                 arrayAuxNode.add( underExtremeNode_Generate(auxiliarMesh.get(i), w0,wf, c, C, inf, sup, testF));
            }
        
            for ( int p = auxiliarMesh.size() - 1 ; (i < quantity) ; p--, i++) {
                 arrayAuxNode.add(overExtremeNode_Generate(auxiliarMesh.get(p), w0,wf, c, C, inf, sup, testF));
            }
        
            if(quantity <= auxiliarMesh.size()){
               for (int k = quantity; k > auxiliarMesh.size() ; k--) {
                  arrayAuxNode.add(Node.randomeNode_Generate(inf, sup, testF)) ;
               }
            }
        return arrayAuxNode;
		
    }
    
    public static Node overExtremeNode_Generate(Node nl, double w0,double wf, int c, int C, double minValue, double maxValue, test_func testF  ) {
        double temp[] = new double[testF.dimension()];
        double auxNl[] = nl.get_ValuesArray();
        for (int i = 0; i < testF.dimension(); i++) {
            double aux=0;
            double weigh = Auxiliar.weigh(w0,wf, c, C);
            if (auxNl[i]>0)
              aux = auxNl[i] +weigh; //* Math.random();//*Auxiliar.halfAmplitude_Calculate(minValue, maxValue);
            else
              aux = auxNl[i] - weigh;//* Math.random();//*Auxiliar.halfAmplitude_Calculate(minValue, maxValue);

            if (aux < minValue) {
                temp[i] = Auxiliar.randomValue_Generate(minValue, Auxiliar.halfAmplitude_Calculate(minValue, maxValue));
            }
            else if (aux > maxValue){
                temp[i] = Auxiliar.randomValue_Generate(Auxiliar.halfAmplitude_Calculate(minValue, maxValue), maxValue);
            }
            else{
                temp[i] = aux;
            }
        }
        return new Node(temp, testF,3);
        
}

public static Node underExtremeNode_Generate(Node nl, double w0,double wf, int c, int C, double minValue, double maxValue, test_func testF  ) {
   double temp[] = new double[testF.dimension()];
        double auxNl[] = nl.get_ValuesArray();
        for (int i = 0; i < testF.dimension(); i++) {
            double aux = 0;
            double weigh = Auxiliar.weigh(w0,wf, c, C);
            if (auxNl[i]>0)
              aux = Math.abs(auxNl[i] - weigh);//* Math.random());//*Auxiliar.halfAmplitude_Calculate(minValue, maxValue);
            else
              aux = Math.abs(auxNl[i] + weigh);//* Math.random());//*Auxiliar.halfAmplitude_Calculate(minValue, maxValue);

            if (aux < maxValue) {
                temp[i] = Auxiliar.randomValue_Generate(minValue, Auxiliar.halfAmplitude_Calculate(minValue, maxValue));
            }
            else if (aux > maxValue){
                temp[i] = Auxiliar.randomValue_Generate(Auxiliar.halfAmplitude_Calculate(minValue, maxValue), maxValue);
            }
            else{
                temp[i] = aux;
            }
        }
        return new Node(temp, testF, 4);
}

}
