/*
 * ParametersException.java
 *
 * Created on January 27, 2008, 5:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package org.vmo.exceptions;

/**
 *
 * @author dhperez
 */
public class ParametersException extends Exception {
    
    /** Creates a new instance of ParametersException */
    public ParametersException() {
        super("Los parametros pasados no son correctos!!!.");
    }
    
}
