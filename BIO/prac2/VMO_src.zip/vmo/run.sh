#!/bin/bash
mvn jar:jar
java -cp target/vmo-1.0-SNAPSHOT.jar org.vmo.core.Main
