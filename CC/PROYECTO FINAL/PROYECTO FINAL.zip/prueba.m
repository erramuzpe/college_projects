function r = prueba(c)

tic

r=roots(c);
toc
end
